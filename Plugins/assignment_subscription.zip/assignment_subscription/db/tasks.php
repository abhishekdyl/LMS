<?php


$tasks = array(
    array(
        'classname' => 'local_assignment_subscription\task\user_subscription',
        'blocking' => 0,
        'minute' => '0',
        'hour' => '23',
        'day' => '*',
        'month' => '*',
        'dayofweek' => '*',
    ),
);