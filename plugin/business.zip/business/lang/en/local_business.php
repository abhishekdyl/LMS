<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Business';
// $string['noskillselected'] = 'Please select atleast one sub skill';
// $string['selectskills'] = 'Sub Skill';

