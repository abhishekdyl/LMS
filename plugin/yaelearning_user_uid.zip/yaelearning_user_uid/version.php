<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_yaelearning_user_uid';
$plugin->version   = 2020306200;
$plugin->release = '1.0';
$plugin->maturity = MATURITY_STABLE;
$plugin->requires  = 2015112900; 