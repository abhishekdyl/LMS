<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'User Unique id';