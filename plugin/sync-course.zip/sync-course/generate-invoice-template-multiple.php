<?php 


if(isset($_POST['chk_box'])){


$chk_box = $_POST['chk_box'];

print_r($chk_box);

// foreach ($chk_box as $key => $value) {
// 	echo $value;
// }

}


?>