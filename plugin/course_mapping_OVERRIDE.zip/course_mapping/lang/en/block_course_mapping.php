<?php
$string['pluginname'] = 'Course Mapping';






