<?php
require('../../config.php');
global $DB, $USER;
require_once($CFG->dirroot.'/user/externallib.php');  

$geturecords = "SELECT u.id,u.username FROM {user} as u JOIN {role_assignments} as ra ON ra.userid=u.id JOIN {role} as r ON r.id=ra.roleid
JOIN {context} as ctx ON ctx.id=ra.contextid JOIN {course} as c ON c.id=ctx.instanceid where ctx.contextlevel=50 AND r.shortname='student' AND c.fullname LIKE'ECCQ%' ";
$EX= new core_user_external();

$userId = $DB->get_records_sql($geturecords);
foreach($userId as $userlist){
$EX->update_user_preferences($userlist->id,1); 
}




 



?>

