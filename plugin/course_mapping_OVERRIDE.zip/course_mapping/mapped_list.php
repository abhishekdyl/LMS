<?php
require('../../config.php');
//require('gear.php');
require_login();
$PAGE->set_context(context_system::instance());
global $DB, $USER;
$delete          = optional_param('delete', 0, PARAM_INT);
$confirm          = optional_param('confirm', "0", PARAM_RAW);
$returnurl = new moodle_url('/blocks/course_mapping/mapped_list.php', array());
$pagetitle = 'Course Mapped List';
$PAGE->set_title($pagetitle);
	if ($delete && confirm_sesskey()) {
        if ($confirm != md5($delete)) {
            echo $OUTPUT->header();
            $fullname = fullname($user, true);
            echo $OUTPUT->heading("Delete mapping");

            $optionsyes = array('delete'=>$delete, 'confirm'=>md5($delete), 'sesskey'=>sesskey());
            $deleteurl = new moodle_url($returnurl, $optionsyes);
            $deletebutton = new single_button($deleteurl, get_string('delete'), 'post');

            echo $OUTPUT->confirm("Are you sure?", $deletebutton, $returnurl);
            echo $OUTPUT->footer();
            die;
        } else if (data_submitted() and confirm_sesskey()) {
            if ($DB->delete_records("course_mapped", array("id"=>$delete))) {
                redirect($returnurl);
            } else {
                redirect($returnurl, 'Failed to delete', null, \core\output\notification::NOTIFY_ERROR);
            }
        }
    }

echo $OUTPUT->header();
$userId = $USER->id;

function get_coursename($courseid){
$getcourse = $DB->get_record_sql("SELECT * FROM {course} WHERE id=$courseid");
return $getcourse;
}
?>
<div class="bundle_table">
	<div class="table_heading"> Course Mapped List </div>
<a class="btn btn-primary" href="<?php  echo $CFG->wwwroot . '/blocks/course_mapping/mapping.php'; ?>" role="button">Mapped Course</a>
	<table id="usetTable" class="table" border="1">
		<thead> 
			<tr> 
				<th>Sl. No.</th>
				<th>From Course</th>                
				<th>To Course </th>				
				<th>Note</th>
               <th>Action</th>
			</tr>
		</thead>
		<tbody>
		 <?php
           $querycourse = "SELECT m.*, GROUP_CONCAT(c.fullname) as fromcourse, c1.fullname as tocourse FROM {course_mapped} m left join {course} c on FIND_IN_SET(c.id, m.from_courseid) left join {course} c1 on c1.id=m.to_courseid group by m.id ORDER BY m.id ASC";
	       $mpcourse = $DB->get_records_sql($querycourse);		 
		   $i = 1;
		   foreach($mpcourse as $course ){
		 ?>
		
			<tr>						
			  <td><?php echo $i . '.'; ?></td>
			  <td><?php echo $course->fromcourse;?></td>
			  <td><?php echo $course->tocourse;?></td>  
              <td><?php echo $course->note;?></td> 
            <td><a href="<?php echo $CFG->wwwroot . '/blocks/course_mapping/mapping.php?id='.$course->id;?>">Edit</a> | <a href="<?php echo $CFG->wwwroot . '/blocks/course_mapping/mapped_list.php?delete='.$course->id.'&sesskey='.sesskey();?>">Delete</a></td> 
			  
			                        						
			                        						
            </tr>
		   <?php 
		   $i++;
		   } ?>
		</tbody>
	</table>
</div>
<?php 
?>






<style>
td.tddanger {
    background-color: #dc3545;
    color: #fff;
}

td.tdsuccess {
    background-color: #28a745;
    color: #fff;
}
.bundle_table table {
    width: 100%;
}
.table_heading {
    color: #fff;
    font-size: 30px;
    text-align: center;
    margin: 10px 0;
    background: #3376d2;
}
.bundle_table{
	margin-top:50px;
}
.bundle_table table tr th,.bundle_table table tr td{
    padding:6px 8px; 
}
.bundle_table thead{
	background:#79aaf1;
}
.bundle_table table{
	border:1px solid #ddd;
}
.job_form label{
	width:100%;
}
.buttons{
	padding-left: 6px;
}
.btn1{
	color:#fff;
	background: #302f61; 
	border:none;
	padding:8px;
}
.btn2{
	color:#fff;
	background: #eb5c09; 
	border:none;
	padding:8px;
}
.page_head{
	padding:15px 0; 
}
</style> 


<?php  echo $OUTPUT->footer(); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->

<script>
	$(document).ready(function() {
		$('#usetTable').DataTable();
	} );
</script>