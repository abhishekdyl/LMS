<?php
defined('MOODLE_INTERNAL') || die;
require_once($CFG->libdir.'/formslib.php');

global $DB, $USER;

class course_mappingform extends moodleform {
    // Define the form
    function definition() {
		 global $CFG,$DB,$USER, $TEXTAREA_OPTIONS;		
		$mform =& $this->_form;
        $getcourse = $DB->get_records_sql("SELECT * FROM {course} ORDER BY fullname ASC");
    	$arr_course = array("Select");
        foreach($getcourse as $key => $course){
            $arr_course[$key] = $course->fullname;
		}
                                                         
		$areanames = array();                                                                                                       
		foreach ($getcourse as $key => $course) {                                                                          
   		 $areanames[$key] = $course->fullname;                                                                 
		}                                                                                                                           
     	 $options = array(                                                                                                           
        'multiple' => true,                                                  
     	'noselectionstring' => "All Course",                                                                
		);         
       $mform->addElement('autocomplete', 'fromcourse', 'From Course', $areanames, $options);
      
      //  $mform->addElement('select', 'md_skills', 'Course', $arr_course);
		//$mform->getElement('md_skills')->setMultiple(true);
		// This will select the skills A and B.		
       $mform->addElement('select', 'to_courseid', 'To Courses', $arr_course);
     $mform->addElement('text', 'note', 'Note', 'maxlength="254" size="50" '); 
     $mform->addElement('hidden', 'id'); 
    
   // $mform->addElement('editor', 'fieldname', get_string('labeltext', 'langfile'));
//$mform->setType('fieldname', PARAM_RAW);
    
    
       $mform->setType('region', PARAM_MULTILANG); 
       $this->add_action_buttons(false, "SAVE");   

    }
	

}