<?php
namespace block_course_mapping\task;
/** 
 * An example of a scheduled task.
 */
class stopnotification extends \core\task\scheduled_task {
 
    /**
     * Return the task's name as shown in admin screens.
     *
     * @return string
     */
    public function get_name() {
        return "Turn of Notification";
    }
 
    /**
     * Execute the task.
     */
    public function execute() { 
      global $DB, $CFG;
        require_once($CFG->dirroot . '/user/lib.php');
        require_once($CFG->dirroot . '/user/editlib.php');
        require_once($CFG->dirroot . '/message/lib.php');

		echo $geturecords = "SELECT u.id,u.username FROM {user} as u JOIN {role_assignments} as ra ON ra.userid=u.id JOIN {role} as r ON r.id=ra.roleid
		JOIN {context} as ctx ON ctx.id=ra.contextid JOIN {course} as c ON c.id=ctx.instanceid where ctx.contextlevel=50 AND r.shortname='student' AND c.fullname LIKE 'lds-demo' ";
		$userlist = $DB->get_records_sql($geturecords);
   // print_r($userlist);
   // die;
		foreach($userlist as $userlists){
       // $emailstop = 0;
			$userid = $userlists->id;
			$otheruser =  core_user::get_user($userid, '*', MUST_EXIST);
			// $otheruser = ($userid == $USER->id) ? $USER : core_user::get_user($userid, '*', MUST_EXIST);
				if (core_message_can_edit_message_profile($otheruser) && $otheruser->emailstop != $emailstop) {
					$user = new stdClass();
					$user->id = $userid;
					$user->emailstop = $emailstop=1;
					user_update_user($user);
				// Update the $USER if we should.
				// if ($userid ==$user->id) {
				// 	$user->emailstop = $emailstop=1;
				// }
			}
		}
      
    }
}


