<?php
require('../../config.php');
require_once($CFG->dirroot.'/lib/enrollib.php');
//require_once($CFG->dirroot.'/lib/accesslib.php');
require_once('mappingform.php');
require_login();
$id          = optional_param('id', 0, PARAM_INT);
$PAGE->set_context(context_system::instance());
global $DB, $USER;
$pagetitle = 'Course Mapping';
$PAGE->set_title($pagetitle);


echo $OUTPUT->header();
$userId = $USER->id;

?>

<div class="C_ours_e">
<div class="container">
	<div class="dash-heading">
    <h3  class="text-center">Course Mappinjg</h3> 

	</div>
</div>
<?php
$addformaaa = new course_mappingform();
if ($addformaaa->is_cancelled()) {
	 redirect($CFG->wwwroot). "/my"; 
	}
elseif($addform = $addformaaa->get_data())
{



$fromform = new stdClass();
//echo "<pre>";
//print_r($addform);

//die;

$coursesID = array();
foreach($addform->fromcourse as $courseid){
array_push($coursesID,$courseid);
//$getcontex = $DB->get_record_sql("SELECT * FROM {context} WHERE instanceid = $courseid AND contextlevel = 50");
//$contex_Id = $getcontex->id;

//$all_user = get_enrolled_users(context $getcontex, $withcapability = '', $groupid = 0, $userfields = 'u.*', $orderby = null,
  //      $limitfrom = 0, $limitnum = 0, $onlyactive = false); 

}
 $course_id = implode(',',$coursesID);
if(!empty($id)){
$mapped_id = $DB->get_record("course_mapped", array("id"=>$id));
if(!empty($mapped_id)){
			$updateorgdtls = new stdClass();
            $updateorgdtls->id = $mapped_id->id;
            $updateorgdtls->from_courseid =  $course_id ;
            $updateorgdtls->to_courseid = $addform->to_courseid;
 			$updateorgdtls->note = $addform->note;
            $updateorgdtls->updated_date = time();
//print_r($updateorgdtls);
//die;
            $updateRecords=$DB->update_record('course_mapped', $updateorgdtls);
if($updateRecords){
redirect(new moodle_url($CFG->wwwroot.'/blocks/course_mapping/mapped_list.php'),'Updated Records successfully.', null, \core\output\notification::NOTIFY_SUCCESS);
}

}

}else{

    //$course_id = implode(',',$coursesID);
    $fromform->from_courseid = $course_id;
    $fromform->to_courseid = $addform->to_courseid;
    $fromform->note = $addform->note;
    $fromform->created_date = time();
    $table = 'course_mapped';
    $insertdata = $DB->insert_record($table, $fromform);
if( $insertdata){
   redirect(new moodle_url($CFG->wwwroot.'/blocks/course_mapping/mapped_list.php'),'Mapped Records successfully.', null, \core\output\notification::NOTIFY_SUCCESS);
}
}
}
if(!empty($id)){
if($data = $DB->get_record("course_mapped", array("id"=>$id))){
	$data->fromcourse = explode(",",$data->from_courseid); 
}

}
if(empty($data)){
    $data  = new stdClass();
    $data->id = $id;
}

$addformaaa->set_data($data);
$addformaaa->display();
?>

<style>
header#page-header .card {
    display:none;
}
</style> 


<?php  echo $OUTPUT->footer(); ?>