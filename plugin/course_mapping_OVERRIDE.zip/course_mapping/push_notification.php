<?php

function push_notification(\core\event\user_enrolment_created $event){

    global $DB, $USER,$CFG; 


    require_once($CFG->dirroot.'/user/externallib.php');
	$geturecords = "SELECT * FROM {course} WHERE id = '".$event->courseid."' AND fullname LIKE 'ECCQ%'";
	$courselist = $DB->get_record_sql($geturecords);
	if(!empty($courselist)){
        $userid = $event->relateduserid;
		$EX= new core_user_external();
		$EX->update_user_preferences($userid,1); 
	}

	

}

?>