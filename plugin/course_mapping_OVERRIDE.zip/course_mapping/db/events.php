<?php

$observers = array(
    
    array(
        'eventname' => '\core\event\course_completed',
        'includefile' => 'blocks/course_mapping/observer.php',
        'callback' => 'course_mapping',
        'internal' => false 
     ),

   array(
        'eventname' => '\core\event\user_updated',
        'includefile' => 'blocks/course_mapping/notification.php',
        'callback' => 'user_updated',
        'internal' => false 
     ),
   array(
        'eventname' => '\core\event\user_enrolment_created\core\event\user_enrolment_created',
        'includefile' => 'blocks/course_mapping/push_notification.php',
        'callback' => 'push_notification',
        'internal' => false 
     )



);

?>