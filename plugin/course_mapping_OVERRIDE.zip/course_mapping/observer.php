<?php

// enrollment function
function enrolCourse($courseid, $userid, $roleid) {  
   
    global $DB, $CFG;
    $query = 'SELECT * FROM {enrol} WHERE enrol = "manual" AND courseid = '.$courseid;
    $enrollmentID = $DB->get_record_sql($query);
    if(!empty($enrollmentID->id)) {
        if (!$DB->record_exists('user_enrolments', array('enrolid'=>$enrollmentID->id, 'userid'=>$userid))) {
            $userenrol = new stdClass();
            $userenrol->status = 0;
            $userenrol->userid = $userid;
            $userenrol->enrolid = $enrollmentID->id;
            $userenrol->timestart  = time();
            $userenrol->timeend = 0;
            $userenrol->modifierid  = 2;
            $userenrol->timecreated  = time();
            $userenrol->timemodified  = time();
            $enrol_manual = enrol_get_plugin('manual');
            $enrol_manual->enrol_user($enrollmentID, $userid, $roleid, $userenrol->timestart, $userenrol->timeend);
            add_to_log($courseid, 'course', 'enrol', '../enrol/users.php?id='.$courseid, $courseid, $userid); //there should be userid somewhere!
            
        }
    }

}

function course_mapping(\core\event\course_completed $event){
	global $DB, $USER,$CFG;
 require_once($CFG->dirroot.'/cohort/lib.php');
        if($event->relateduserid && $event->courseid){
       // print_r($event);
        	$userid = $event->relateduserid;
        	$contextid = $event->contextid;
           // $mappingsetting = $DB->get_records('course_mapped',array('from_courseid'=>$event->courseid));
          $mappingsetting = $DB->get_records_sql('select * from {course_mapped} where FIND_IN_SET(?,from_courseid)',array($event->courseid));
			foreach($mappingsetting as $setting){
            	if($existingrole = $DB->get_record("role_assignments", array("contextid"=>$contextid , "userid"=>$userid, "roleid"=>5))){
            	 enrolCourse($setting->to_courseid, $userid, $existingrole->roleid);
                } 
            $course = $DB->get_record("course", array("id"=>$setting->to_courseid));
                   if($getcontex = $DB->get_record_sql("SELECT * FROM {context} WHERE instanceid = $course->category AND contextlevel = 40")){

                   	$cohorts = $DB->get_records("cohort", array("contextid"=>$getcontex->id, "name"=>$course->shortname));
                    if(empty($cohorts)){
                    	$newcohort = new stdClass();
                   		$newcohort->name 		= $course->shortname;
                    	$newcohort->idnumber 	= $course->shortname;
                    	$newcohort->contextid 	= $getcontex->id;
                    	$newcohort->visible 	= 1;
                    	//echo "<pre>";
                    //	print_r($newcohort);
                    
                    	$insertcohort = cohort_add_cohort($newcohort);
                    if($insertcohort){
                   // print_r($insertcohort);
                     	cohort_add_member($insertcohort, $userid);         
                    }
                    }else{  
                       $cohorts = $DB->get_records("cohort", array("contextid"=>$getcontex->id, "name"=>$course->shortname));
                    //print_r($cohorts);
                    foreach($cohorts as $cohort){
                    	cohort_add_member($cohort->id, $userid);
                    }
                    	                  
                    }                            
                    
                 
					
                   
                   }

				
            }
        
          $passedcourse  = $DB->get_records_sql("select * from {course_mapped} where to_courseid='".$event->courseid."'");
        foreach($passedcourse as $settings){
            
            $course = $DB->get_record("course", array("id"=>$setting->to_courseid));
                   if ($getcontex = $DB->get_record_sql("SELECT * FROM {context} WHERE instanceid = $course->category AND contextlevel = 40")){

                   
                    $cohorts = $DB->get_record_sql("select * from {cohort} where name LIKE 'GRADUATES' ");
                  
                   
                  
                   // print_r($insertcohort);
                     	cohort_add_member($insertcohort, $userid);         
                  
                                          
                    
                 
					
                   
                   }

				
            }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


        }


}