<?php
  require_once("../../config.php");
  require_login();
  $id = optional_param("id", "");
  if(empty($id)){
    redirect("{$CFG->wwwroot}/reports");
  }
  $attemptpath = my_decrypt(urldecode($id));
  $attemptdata = json_decode(getFile("{$CFG->syncdataroot}/$attemptpath"));
  if(empty($attemptdata)){
    redirect("{$CFG->wwwroot}/reports");
  }
  $allusers = get_allusers()->credentials;
  $index = array_search($attemptdata->userid, array_column((array)$allusers, 'id'));
  $attemptdata->user = $allusers[$index];
  $OUTPUT->loadjquery();
  echo $OUTPUT->header();
  $html = '';
//  $html .= '<pre>'.print_r($attemptdata, true).'</pre>';
  $html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card1">
                <div class="card-body">
                  <p class="card-title mb-0"><a class="btn btn-secondary" href="'.$CFG->wwwroot.'/reports/">Back</a></p>
                  <div class="text-right">
                  </div>
                  <br/>';
  $html .='<div id="print_homeworkreport">    
    <div class="row">
      <div class="col-sm-9">
        <div class="forms-sample blueform row">
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Level</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.(isset($attemptdata->grade)?$attemptdata->grade:'').'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Semester/Unit</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.(isset($attemptdata->topicname)?$attemptdata->topicname:'').'">
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Lesson/Assessment</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.(isset($attemptdata->subtopicname)?$attemptdata->subtopicname:'').'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Task</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.(isset($attemptdata->quizname)?$attemptdata->quizname:'').'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Attempt</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.$attemptdata->attempt.'">
                <input type="hidden" id="id" value="'.$id.'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Device</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.(isset($attemptdata->devicename)?$attemptdata->devicename:'').'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">User</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.(is_object($attemptdata->user)?"{$attemptdata->user->firstname} {$attemptdata->user->lastname}":$attemptdata->userid).'">
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="col-sm-3" style="font-size:15px;">
      <span class="smalldot gray"></span>&nbsp; &nbsp;<span style="">Incomplete</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #ffffff"></span>&nbsp; &nbsp;<span style="">Unstarted</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #FF0000"></span>&nbsp; &nbsp;<span style="">Not meeting</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #fff53b"></span>&nbsp; &nbsp;<span style="">Approaching Expectation</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #00FF33"></span>&nbsp; &nbsp;<span style="">Meeting Expectation</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #0100f3"></span>&nbsp; &nbsp;<span style="">Exceeding Expectation</span><br><br><br> 
    </div>
  </div><br><br><div class="table-responsive"><table class="reporttable" border="1" style="border-color: #e0ebeb;table-layout: fixed; width:100%;">
    <tbody>
      <tr>
        <td colspan="2" style="width:140px;">Completion date </td>';
    foreach ($attemptdata->questions as $key => $question) {
      $html .='
        <th class="text-center viewquestion" style="font-size: 12px; width:100px;">
          <div class="strands_competencies">
            <div class="text-left">
              <p style="font-size:12px; margin:0;">Q'.($key+1).'</p>
              <p style="font-size:12px; margin:0;">('.$question->maxMarks.')</p>
            </div>
            <div class="text-right">
            </div>
          </div>
        </th>';
    }
    $reporthtml= "";
    $reporthtml .='
      <tr>
        <td style="font-size:11px;padding:5px;width:140px;" colspan="2">'.plus_dateToFrench($attemptdata->submissiontime).'</td>';
        $sum = 0;
        $sumtotal = 0;
    foreach ($attemptdata->questions as $key => $question) {
      $sum += $question->marks;
      $sumtotal += $question->maxMarks;
      $dotcolor = "";
      if(empty(floatval($question->marks)) || empty(floatval($question->maxMarks)) ){ $dotcolor="red";} 
      else if($question->marks/$question->maxMarks>=0.85){ $dotcolor="blue"; }
      else if($question->marks/$question->maxMarks>=0.70){ $dotcolor="lightgreen";}
      else if($question->marks/$question->maxMarks>=0.50){ $dotcolor="yellow";}
      else { $dotcolor="red";}

      $reporthtml .='
        <td class="text-center" style="font-size:11px;padding:5px;">'.number_format($question->marks, 2).'<br><span class="smalldot '.$dotcolor.'"></span></td>';
    }
	$finalmarks = $sum;
	$finaltotalmarks = $sumtotal;
	if(isset($attemptdata->grademax) && !empty($attemptdata->grademax)){
		$finalmarks = ($sum/$sumtotal)*$attemptdata->grademax;
		$finaltotalmarks = $attemptdata->grademax;
	}
    $reporthtml .='
      <td class="text-center" style="font-size:11px;padding:5px;">'.number_format($finalmarks, 2).'<br><span class="smalldot gray"></span></td>';
    $reporthtml .='
      </tr>';
  $html .='
        <th class="text-center" style="font-size: 12px; width:45px;">
			<p style="font-size:12px; margin:0;">Score</p>
			'.(!empty($finaltotalmarks)?'<p style="font-size:12px; margin:0;">('.number_format($finaltotalmarks, 2).')</p>':'').'
		</th>
      </tr>
      ';
  $html .= $reporthtml;
  $html .='
      </tbody></table></div>
</div>';
  $html .='
                </div>
              </div>
            </div>
          </div>';
  echo $html;
  echo $OUTPUT->footer();