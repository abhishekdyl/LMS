<?php
  require_once("../../config.php");
  $syncnow = optional_param("syncnow", "");
  if($syncnow){
    syncAlluserdata($syncnow);
    redirect("{$CFG->wwwroot}/reports");
  }
  require_login();
  $OUTPUT->loadjquery();
  echo $OUTPUT->header();
  $alllocaldatafiles = get_alllocaldata();

$html = '';
//$html .= '<pre>'.print_r($alllocaldatafiles, true).'</pre>';
$html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <p class="card-title mb-0">'.get_string("userdata", "site").' <span class="badge">'.get_string("lastsynced",'site').': '.plus_dateToFrench($LOCAL->datalastsynced).'</span></p>
                  <div class="text-right">
                  '.(has_internet()?'<a class="btn btn-primary" href="'.$CFG->wwwroot.'/reports?syncnow=all">'.get_string("syncnow",'site').'</a>':'').'
                    
                  </div>
                  <br/>
                  <div class="table-responsive">
                    <table id="userlist" class="table plus_local_datatable table-borderless">
                      <thead>
                        <tr>
                          <th class="border-bottom pb-2">'.get_string("slno",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("user",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("level",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("semester",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("lesson",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("quiz",'form').'</th>
                          <th class="pl-0  pb-2 border-bottom">'.get_string("devicename",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("submissiondate",'form').'</th>
                          <th class="border-bottom pb-2">'.get_string("finished",'form').'Finished</th>
                          <th class="border-bottom pb-2">'.get_string("synced",'form').'Synced</th>
                          <th class="border-bottom pb-2"></th>
                        </tr>
                      </thead>
                      <tbody>';
  if(is_array($alllocaldatafiles)){
    $allusers = get_allusers()->credentials;
	$counter = 0;
	$alllocaldatafiles = array_reverse($alllocaldatafiles);
    foreach ($alllocaldatafiles as $key => $attempt) {
      $attemptdata = json_decode(getFile("{$CFG->syncdataroot}/$attempt"));
      $index = array_search($attemptdata->userid, array_column((array)$allusers, 'id'));
      $attemptdata->user = isset($allusers[$index])?$allusers[$index]:null;
      if(is_object($attemptdata) && !empty($attemptdata->user)){
		  $counter++;
        $html .='<tr>
          <td>'.$counter.'</td>
          <td>'.(is_object($attemptdata->user)?"{$attemptdata->user->firstname} {$attemptdata->user->lastname}":$attemptdata->userid).'</td>
          <td>'.(isset($attemptdata->grade)?$attemptdata->grade:'').'</td>
          <td>'.(isset($attemptdata->topicname)?$attemptdata->topicname:'').'</td>
          <td>'.(isset($attemptdata->subtopicname)?$attemptdata->subtopicname:'').'</td>
          <td>'.(isset($attemptdata->quizname)?$attemptdata->quizname:'').'</td>
          <td>'.(isset($attemptdata->devicename)?$attemptdata->devicename:'').'</td>
          <td>'.plus_dateToFrench($attemptdata->submissiontime).'</td>
          <td>'.($attemptdata->isfinished?'yes':'').'</td>
          <td>'.(in_array($attempt, $LOCAL->syncedfiles)?'yes':'<a class="btn btn-primary" href="'.$CFG->wwwroot.'/reports/?syncnow='.md5($attempt).'">Sync It</a>').'</td>
          <td><a href="'.$CFG->wwwroot.'/reports/details/?id='.urlencode(my_encrypt($attempt)).'"><i class="mdi mdi-pulse"></i> Report</a></td>
        </tr>';
      }
    }
  }
  $html .='
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  $html .='';
  echo $html;
  echo $OUTPUT->footer();