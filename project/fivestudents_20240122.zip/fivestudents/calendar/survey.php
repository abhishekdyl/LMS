<?php
require_once("../config.php");
global $DB, $PAGE, $CFG, $USER, $OUTPUT, $INSTITUTION;
require_login();
$OUTPUT->loadjquery();
$html .='<div class="surveyattempt"> <table><tbody><tr><th>Survey</th><th>Action</th></tr><tr><td>Questionnaire_FR</td><td><button data-id="1" data-eventid="165" data-container="[surveyplayercontainer]" startsurvey="">Start</button></td></tr><tr><td>sushil test 1</td><td><button data-id="2" data-eventid="165" data-container="[surveyplayercontainer]" startsurvey="">Start</button></td></tr></tbody></table></div>
    <div surveyplayercontainer></div>
    ';
echo $OUTPUT->header();
echo $html;
echo $OUTPUT->footer();