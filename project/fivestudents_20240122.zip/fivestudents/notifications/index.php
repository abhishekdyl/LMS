<?php
require_once("../config.php");
global $API;
$formdata = new stdClass();
$formdata->id = optional_param("id", 0);
$APIRESnotify = $API->call("getInstituteNotification");
$array_mess = $APIRESnotify; 
require_login();

  $html ='';
  // $html .='<pre>'.print_r($APIRESnotify, true).'</pre>';
  $html .=  '<div class="row">
            <div class="col-md-12 grid-margin transparent">
              <div class="row">';
  $html .=  '<div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body haveaction">
                  <h4 class="card-title">'.get_string("title", "notification").'</h4>
                  <div class="table-responsive">
                    <table class="table table-striped plus_local_datatable" id="notifications">
                      <thead>
                        <tr>
                          <th>'.get_string("slno", "notification").'</th>
                            <th>'.get_string("schoolname", "notification").'</th>
                            <th>'.get_string("teachername", "notification").'</th>
                          <th>'.get_string("eventdate", "notification").'</th>
                          <th>'.get_string("status", "notification").'</th>
                          <th>'.get_string("comment", "notification").'</th>
                          <th>'.get_string("lastupdated", "notification").'</th>
                        </tr>
                      </thead>
                      <tbody>';
              if(is_object($APIRESnotify) && is_array($APIRESnotify->data->notifications)){
                $counter = 0;
                foreach ($APIRESnotify->data->notifications as $key => $notification) {
                  $counter++;
                  $html .=  '<tr '.($formdata->id == $notification->id?'class="selected"':'').'>
                              <td>'.$counter.'</td>
                              <td>'.$notification->schoolname.'</td>
                              <td>'.$notification->teachername.'</td>
                              <td>'.plus_dateToFrench($notification->timestart).'</td>
                              <td>'.get_string("status_{$notification->status}", "calendar").'</td>
                              <td>'.$notification->comment.'</td>
                              <td>'.plus_dateToFrench($notification->lastupdated).'</td>
                              </tr>';
                }
              }
            $html .=  '</tbody>
                    </table>
                  </div>';
  $html .=      '</div>
              </div>
            </div>
          ';
  $html .=  '</div>
            </div>
          </div>';


echo $OUTPUT->header();
echo $html;
echo $OUTPUT->footer();