<?php
  require_once("config.php");
  redirect("{$CFG->wwwroot}/dashboard/");
  exit;
