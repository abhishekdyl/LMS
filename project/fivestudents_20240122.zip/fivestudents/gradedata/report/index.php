<?php
  require_once("../../config.php");
  require_login();
  $homeworkid = optional_param("homeworkid", 0);
  if(empty($homeworkid)){
    redirect("{$CFG->wwwroot}/homeworks");
  }
  $homework = get_homeworkreport($homeworkid);
  if(empty($homework)){
    redirect("{$CFG->wwwroot}/homeworks");
  }
  $OUTPUT->loadjquery();
  echo $OUTPUT->header();
  
  // echo "<pre>";
  // print_r($homework);
  // die();
 
  $html = '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card1">
                <div class="card-body">
                  <p class="card-title mb-0"></p>
                  <div class="text-right">
                  </div>
                  <br/>';
  $html .='<div id="print_homeworkreport">    
    <div class="row">
      <div class="col-sm-9">
        <div class="forms-sample blueform row">
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Level</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.$homework->grade.'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Group</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.$homework->group_name.'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Mode</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="Mode">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Semester/Unit</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.$homework->topicname.'">
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Lesson/Assessment</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.$homework->subtopicname.'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Task</span>
                </div>
                <input type="text" readonly="readonly" disabled="disabled" class="form-control hovernormal" value="'.$homework->quizname.'">
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">Attempt</span>
                </div>
                <select name="attempt" class="form-control" id="attempt" required="required">
                  <option value="1" selected="">1st attempt</option>
                  <option value="2">best attempt</option>
                </select>
                <input type="hidden" id="groupid" value="'.$homework->groupid.'">
                <input type="hidden" id="homeworkid" value="'.$homework->id.'">
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="col-sm-3" style="font-size:15px;">
      <span class="smalldot gray"></span>&nbsp; &nbsp;<span style="">Incomplete</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #ffffff"></span>&nbsp; &nbsp;<span style="">Unstarted</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #FF0000"></span>&nbsp; &nbsp;<span style="">Not meeting</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #fff53b"></span>&nbsp; &nbsp;<span style="">Approaching Expectation</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #00FF33"></span>&nbsp; &nbsp;<span style="">Meeting Expectation</span><br>
      <span class="dot" style="width:10px; height:10px; border-radius: 50%; background-color: #0100f3"></span>&nbsp; &nbsp;<span style="">Exceeding Expectation</span><br><br><br> 
    </div>
  </div><br><br><div class="table-responsive"><table class="reporttable" border="1" style="border-color: #e0ebeb;table-layout: fixed; width:100%;">
    <tbody>
      <tr>
        <td class="studentname" colspan="4" style="width:140px;"></td>
        <td colspan="4" style="width:140px;">Completion date </td>';
    for ($i=1; $i <= $homework->totalquestion; $i++) { 
      $html .='
        <th class="text-center viewquestion" style="font-size: 12px; width:100px;">
          <div class="strands_competencies">
            <div class="text-left">
              <p style="font-size:12px; margin:0;">Q'.$i.'</p>
              <p style="font-size:12px; margin:0;">(2.00)</p>
            </div>
            <div class="text-right">
            </div>
          </div>
        </th>';
    }
  $html .='
        <th class="text-center" style="font-size: 12px; width:70px;">
            <div class="text-center">
              <p style="font-size:12px; margin:0;">Score</p>
          </div></th>
      </tr>';
  $roundon =10;    
      
    $attempthtml='';
    $finalscore = array('score'=>0, 'count'=>0);
    foreach ($homework->users as $key => $user) {
      $attemptdata = $user->attemptdata;
    	$userid = $user->id;
    	$attempthtml .='
    	<tr>
    		<td style="font-size:11px;padding:5px;" colspan="4">'.$user->id.' '.$user->firstname.' '.$user->lastname.'</td>
    		<td style="font-size:11px;padding:5px;width:140px;" colspan="4">'.plus_dateToFrench($attemptdata->submissiontime).'</td>';
		
        if($attemptdata->isattempted){
          $qt = 0;
          $qmt = 0;
          for ($i=0; $i < $homework->totalquestion; $i++) { 
            $question = $attemptdata->questions[$i];
          // foreach ($attemptdata->questions as $key => $question) {
            if(!isset($overallqt[$i])){$overallqt[$i] = array("qt"=>0, "qmt"=>0, "qmtm"=>0, "type"=>$question->type);}
            if($question->type == 'description'){ continue; }
            if($question->isAttempted){
              if($attemptdata->isfinished){
                $overallqt[$i]['qt']+=$question->marks;
                $overallqt[$i]['qmt']++;
                $overallqt[$i]['qmtm']+=$question->maxMarks;
                $qt+=$question->marks;
                $qmt+=$question->maxMarks;
              }
              $dotcolor = "";
              if(empty(floatval($question->marks)) || empty(floatval($question->maxMarks)) ){ $dotcolor="red";} 
              else if($question->marks/$question->maxMarks>=0.85){ $dotcolor="blue"; }
              else if($question->marks/$question->maxMarks>=0.70){ $dotcolor="lightgreen";}
              else if($question->marks/$question->maxMarks>=0.50){ $dotcolor="yellow";}
              else { $dotcolor="red";}
              $percentscore = 1;
              $attempthtml .='<td class="text-center" style="font-size:11px;padding:5px;">'.$question->marks.'<br><span class="smalldot '.$dotcolor.'"></span></td>';
            } else {
              $attempthtml .='<td class="text-center" style="font-size:11px;padding:5px;"><span class="smalldot gray"></span></td>';
            }
          }
          $dotcolor = "";
          if(!$attemptdata->isfinished){
            $attempthtml .='<td class="text-center" style="font-size:11px;padding:5px;">N/C<br><span class="smalldot gray"></span></td>';
          } else {
            if(empty($qt) || empty($qmt)){ $dotcolor="red";} 
            else if($qt/$qmt>=0.85){ $dotcolor="blue"; }
            else if($qt/$qmt>=0.70){ $dotcolor="lightgreen";}
            else if($qt/$qmt>=0.50){ $dotcolor="yellow";}
            else { $dotcolor="red";}
            if(empty($qmt)){
              $finalqtn = 0;
            } else {
              $finalqtn = ($qt/$qmt*$roundon);
            }
            $finalqt = number_format($finalqtn, 2);
            $finalscore['score']+=$finalqt;
            $finalscore['count']++;
            $attempthtml .='<td class="text-center" style="font-size:11px;padding:5px;">'.$finalqt.'<br><span class="smalldot '.$dotcolor.'"></span></td>';
          }
        } else {
          // foreach ($APIRES->data->reportdata->allquestions as $key => $question) {
          for ($i=0; $i < $homework->totalquestion; $i++) { 
            $question = $attemptdata->questions[$i];
            if($question->type == 'description'){ continue; }
              $attempthtml .='<td class="text-center" style="font-size:11px;padding:5px;"><span class="smalldot gray"></span></td>';
          }
          $attempthtml .='<td class="text-center" style="font-size:11px;padding:5px;"><span class="smalldot gray"></span></td>';
        }



	// 	$score = 0;
	// 	for ($i=0; $i < $homework->totalquestion; $i++) { 
  // 		if($user->id == $userid){ $mark = $attemptdata->questions[$i]->marks; $score += $mark; array_push($group_average, $mark);  }
  // 		$attempthtml .='
  // 		<td class="text-center" style="font-size:11px;padding:5px;">'.$mark.'<br><span class="smalldot gray"></span></td>';
	// 	}
		
	// 	$attempthtml .='
	// 	<td class="text-center" style="font-size:11px;padding:5px;">'.$score.'<br><span class="smalldot gray"></span></td>';
	// 	$attempthtml .=
		
	// '</tr>';
	
	// 	$sum[$j] = array_slice($group_average, $initial, $end);
	// 	$initial += ($initial+$end);
	// 	$end += ($end*$total_users);
      
	// $j++;
	  
    }
$htmlhead = "";
$htmlhead .='<tr>';
$htmlhead .='<td colspan="4">Group Average</td>';
$htmlhead .='<th colspan="4"></th>';
foreach ($overallqt as $key => $ovrall) {
  if($ovrall['type'] == 'description'){ continue; }
  $dotcolor = "";
  if(empty($ovrall['qt']) || empty($ovrall['qmtm'])){ $dotcolor="red";} 
  else if($ovrall['qt']/$ovrall['qmtm']>=0.85){ $dotcolor="blue"; }
  else if($ovrall['qt']/$ovrall['qmtm']>=0.70){ $dotcolor="lightgreen";}
  else if($ovrall['qt']/$ovrall['qmtm']>=0.50){ $dotcolor="yellow";}
  else { $dotcolor="red";}
  if(empty($ovrall['qt']) || empty($ovrall['qmt'])){ 
    $finalqt = number_format(0, 2);
  } else {
    $finalqt = number_format(($ovrall['qt']/$ovrall['qmt']), 2);
  }
  $htmlhead .='<td class="text-center" style="font-size:12px;padding:5px;">'.$finalqt.'<br><span class="smalldot '.$dotcolor.'"></span></td>';
}
  $dotcolor = "";
  // print_r($finalscore);
  // die;
  if(empty($finalscore['score']) || empty($finalscore['count'])){ $dotcolor="red";} 
  else if($finalscore['score']/$finalscore['count']/$roundon>=0.85){ $dotcolor="blue"; }
  else if($finalscore['score']/$finalscore['count']/$roundon>=0.70){ $dotcolor="lightgreen";}
  else if($finalscore['score']/$finalscore['count']/$roundon>=0.50){ $dotcolor="yellow";}
  else { $dotcolor="red";}
  if(empty($finalscore['score']) || empty($finalscore['count'])){ 
    $finalqt = number_format(0, 2);
  } else {
    $finalqt = number_format(($finalscore['score']/$finalscore['count']), 2);
  }
$htmlhead .='<td class="text-center" style="font-size:12px;padding:5px;">'.$finalqt.'<br><span class="smalldot '.$dotcolor.'"></span></td>';
$htmlhead .='</tr>';
     
	  $html .=$htmlhead.$attempthtml;
    
  $html .='
      </tbody></table></div>
</div>';
  $html .='
                </div>
              </div>
            </div>
          </div>';
  echo $html;
  echo $OUTPUT->footer();
