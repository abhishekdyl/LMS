<?php
  require_once("../config.php");
  require_login();
  $syncnow = optional_param("syncnow", 0);
  $upgradedata = optional_param("upgradedata", "");
  $pendingsdata = optional_param("pendingsdata", "");
  $fetch = optional_param("fetch", 0);
  $updates = optional_param("updates", []);
  if($fetch){
    fetch_awaitingsynceddata();
    redirect("{$CFG->wwwroot}/gradedata");
  }
  $OUTPUT->loadjquery();
  $awaitingdata = get_awaitingsynceddata("awaiting");
  $synceddata = get_awaitingsynceddata("synced");
  $lastsynced = get_string("lastfetched",'form');
  if(is_object($synceddata) && !empty($synceddata->updateddate)){
    $lastsynced = plus_dateToFrench($synceddata->updateddate);
  }
  $lastfetched = get_string("lastfetched",'form');
  if(is_object($awaitingdata) && !empty($awaitingdata->updateddate)){
    $lastfetched = plus_dateToFrench($awaitingdata->updateddate);
  }
  $requireupgrade = false;
  $requireupgradedata = array();
  if(is_object($awaitingdata) && is_array($awaitingdata->data)){
    foreach ($awaitingdata->data as $key => $data) {
      $found_key = array_search($data->id, array_column($synceddata->data, 'id'));
      if($found_key !== false){
        $founddata = $synceddata->data[$found_key];
        if($founddata->processtime < $data->processtime){
          $data->existing = true;
          array_push($requireupgradedata, $data);
          $requireupgrade = true;
        }
      } else {
        $data->existing = false;
        array_push($requireupgradedata, $data);
        $requireupgrade = true;
      }
    }
  }
  // if(sizeof($requireupgradedata)==0){
  //   redirect("{$CFG->wwwroot}", "All Data is already synced", "info");
  //   exit;
  // }
  echo $OUTPUT->header();
  if($upgradedata){
    if($upgradedata == 'upgradedataall'){
      $updates = explode(",", $pendingsdata);
    }
    echo '<div class="synceddatastatus">';
      // echo '<h2 class="text-uppercase">theme_academi</h2><div class="alert alert-success" role="alert">Success (1.16 seconds)</div><hr>';
    set_time_limit(0);
    foreach ($updates as $key => $update) {
      $found_key = array_search($update, array_column($requireupgradedata, 'id'));
      if($found_key !== false){
        $updatedata = $requireupgradedata[$found_key];
        $syncedstatus = syncmoduledata($updatedata);
        if($syncedstatus){
          echo '<h4 class="text-uppercase">'.$updatedata->finalname.'</h4><div class="alert alert-success" role="alert">Success</div><hr>';
        } else {
          echo '<h4 class="text-uppercase">'.$updatedata->finalname.'</h4><div class="alert alert-error" role="alert">Failed</div><hr>';
        }
      }
    }
    echo '</div>';
    redirect("{$CFG->wwwroot}/gradedata", "Data Synced successfully");
  } else {
    $html = '<div class="row">
              <div class="col-12 stretch-card grid-margin">
                <div class="card">
                  <div class="card-body">
                    <p class="card-title mb-0">'.get_string("awaitingsynced",'site').' <span class="badge">'.get_string("lastfetched",'form').': '.$lastfetched.',</span><span class="badge">'.get_string("lastsynced",'site').': '.$lastsynced.'</span></p>
                    <div class="text-right">
                      <a class="btn btn-primary" href="'.$CFG->wwwroot.'/gradedata?fetch=1">'.get_string("fetchstatus",'form').'</a>
                    </div>
                    <br/>
                    <div class="table-responsive">
                      <form method="POST">
                        <table id="userlist" class="table">
                          <thead>
                            <tr>
                              <th class="border-bottom pb-2">'.get_string("select",'form').'</th>
                              <th class="border-bottom pb-2">'.get_string("name",'form').'</th>
                              <th class="border-bottom pb-2">'.get_string("newversion",'form').'</th>
                              <th class="border-bottom pb-2">'.get_string("status",'form').'</th>
                            </tr>
                          </thead>
                          <tbody>';
    if(sizeof($requireupgradedata)>0){
      $counter = 0;
      $pendings = array();
      foreach ($requireupgradedata as $key => $data) {
        $checkbox  ='';
        $status  ='<span class="badge badge-info">Not yet ready</span>';
        if($data->isready && !empty($data->filepath)){
          $checkbox='<input type="checkbox" checked name="updates[]" value="'.$data->id.'" id="eleid'.$data->id.'"/>';
          $counter++;
          $status = (
            $data->existing?'<span class="badge badge-warning">To be Updated</span>':'<span class="badge badge-success">To be added</span>'
            );
          array_push($pendings, $data->id);
          if($counter >=100){continue;}
        }
        $html .='<tr class="">
          <td class="">'.$checkbox.'</td>
          <td class=""><level for="eleid'.$data->id.'" >'.$data->finalname.'</level></td>
          <td class="">'.$data->processtime.'</td>
          <td class="">'.$status.'</td>
        </tr>';
      }

    } else {
      $html .= '<tr><td class="text-center" colspan="4">'.get_string("alreadysynced",'form').'</td></tr>';
    }
    $html .='
                          </tbody>
                        </table>';
    if($requireupgrade){
      $html .='<br/><br/>
      <input type="hidden" name="pendingsdata" value="'.implode(",", $pendings).'" />
      <div class="text-center"><button class="btn btn-primary" value="upgradedata" type="submit" name="upgradedata">'.get_string("syncselected",'form').'</button>
      '.(sizeof($pendings)>0?'<button class="btn btn-primary" value="upgradedataall" type="submit" name="upgradedata">'.get_string("syncallnow",'site').'</button>':'').'
      </div>';
    }
    $html .='
                      </form>
                    </div>
                    
                  </div>
                </div>
              </div>
            </div>';
    $html .='';
    echo $html;
  }
  echo $OUTPUT->footer();
