<?php
unset($CFG);  // Ignore this line
global $CFG;  // This is necessary here for PHPUnit execution
$CFG = new stdClass();
$CFG->wwwroot = "http://local.fivestudents";
$CFG->apiroot = "https://portal.fivestudents.com";
$CFG->wproot = "https://plus.fivestudents.com";
$CFG->key = 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';
$CFG->syncapicount = 2000;
$CFG->dataroot = dirname(__DIR__, 2)."/userdata";
error_reporting(1);
ini_set('max_input_vars', 5000);
require_once("setup.php");