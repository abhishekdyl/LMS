<?php
  require_once("../config.php");
  require_login();
  $syncnow = optional_param("syncnow", 0);
  if($syncnow){
    syncAlldevicelist();
    redirect("{$CFG->wwwroot}/devices-list/");
  }
  $OUTPUT->loadjquery();
  $devicelist = get_alldevicelist();
  $totalkeys = 0;
  if($devicelist){
    $totalkeys = $devicelist->allowedkeys;
    $devices = $devicelist->deviceslist;
  }
  echo $OUTPUT->header();
  $html = '';
  $html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <p class="card-title mb-0">'.get_string("devices", "site").' ('.$totalkeys.')</p>
                  <div class="text-right">
                  '.(has_internet()?'<a class="btn btn-primary" href="'.$CFG->wwwroot.'/devices-list/?syncnow=1">'.get_string("syncnow",'site').'</a>':'').'
                  </div>
                  <br/>
                  <div class="table-responsive">
                    <table id="userlist" class="table plus_local_datatable table-borderless">
                      <thead>
                        <tr>
                          <th>'.get_string("devicekey", "form").'</th>
                          <th>'.get_string("status", "form").'</th>
                          <th>'.get_string("devicetoken", "form").'</th>
                          <th>'.get_string("devicename", "form").'</th>
                          <th>'.get_string("linkeddate", "form").'</th>
                        </tr>
                      </thead>
                      <tbody>';
                      foreach ($devices as $key => $device) {
                     $html .=  '<tr>
                              <td class="py-1">'.$device->devicekey.'</td>
                              <td class="py-1">'.($device->devicetoken?"Activated":"Not Activated").'</td>
                              <td class="py-1">'.$device->devicetoken.'</td>
                              <td class="py-1">'.$device->devicename.'</td>
                              <td class="py-1">'.(!empty($device->linkeddate)?plus_dateToFrench($device->linkeddate):'').'</td>
                              </tr>';
                      }
  $html .='
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  $html .='';
  echo $html;
  echo $OUTPUT->footer();
