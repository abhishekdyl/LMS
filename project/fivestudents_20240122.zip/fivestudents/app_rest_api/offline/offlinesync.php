<?php
require_once("../../config.php");
require_once("index_class.php");
define('NO_DEBUG_DISPLAY', true);
define('WS_SERVER', true);
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
header("HTTP/1.0 200 Successfull operation");

$content = file_get_contents($_FILES['localfile']['tmp_name']);
$errormessage = check_validateUserResponse($content);
$logdata = new stdClass();
$logdata->wsfunction="offlinesync";
$logdata->wsargs=$content;
$logdata->apiresponse=new stdCLass();
if(is_array($errormessage) && sizeof($errormessage)>0){
    $logdata->apiresponse->code=400;
    $logdata->apiresponse->status=0;
    $logdata->apiresponse->message="failed";
    $logdata->apiresponse->data=array("status"=>0, "message"=>implode(", ", $errormessage));
    echo json_encode(array("status"=>0, "message"=>implode(", ", $errormessage)));
} else {
    if($_FILES["localfile"]){
        $contentdata = $content;
        if(is_string($content)){
            $content = json_decode($content);
        }
		$content->submissiondate = strtotime(date("d F Y", $content->submissiondate));
        $target_dir = "/{$content->submissiondate}/{$content->quizid}/{$content->userid}/{$content->devicetoken}/";
        $filename = "quiz_{$content->quizid}_userid_{$content->userid}_attempt_{$content->attempt}_{$content->submissiondate}_quiz.tmp";
		$filepath = $target_dir.$filename;
        if (saveFileTo("syncdataroot",$target_dir, $filename, $contentdata)) {
            $logdata->apiresponse->code=200;
            $logdata->apiresponse->status=1;
            $logdata->apiresponse->message="success";
            $logdata->apiresponse->data=array("status"=>1, "message"=>"Uploaded Successfull", "filepath"=>$filepath);
            echo json_encode(array("status"=>1, "message"=>"Uploaded Successfull", "filepath"=>$filepath));
        } else {
            $logdata->apiresponse->code=400;
            $logdata->apiresponse->status=0;
            $logdata->apiresponse->message="failed";
            $logdata->apiresponse->data=array("status"=>0, "message"=>"Failed to upload data", "filepath"=>$filepath);
            echo json_encode(array("status"=>0, "message"=>"Failed to upload data", "filepath"=>$filepath));
        }
    } else {
        $logdata->apiresponse->code=400;
        $logdata->apiresponse->status=0;
        $logdata->apiresponse->message="failed";
        $logdata->apiresponse->data=array("status"=>0, "message"=>"Unable to get file");
        echo json_encode(array("status"=>0, "message"=>"Unable to get file"));
    }
}
local_saveapilog($logdata);
