<?php
require_once("../../config.php");
require_once("index_class.php");
define('NO_DEBUG_DISPLAY', true);
define('WS_SERVER', true);
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
header("HTTP/1.0 200 Successfull operation");
global $wstoken, $lang, $PARENTUSER, $CATGRADE;
$getpatameter=json_decode(file_get_contents('php://input',True),true);
$functionname = "millsing";
$wstoken = "";
$lang = "fr";
$args = array();
if($getpatameter && isset($getpatameter['wsfunction'])){
    $functionname = $getpatameter['wsfunction'];
}
if($getpatameter && isset($getpatameter['wsargs'])){
    $args = $getpatameter['wsargs'];
}
if($getpatameter && isset($getpatameter['wstoken'])){
    $wstoken = $getpatameter['wstoken'];
}
$baseobject = new LOCALAPIManager();
if (method_exists($baseobject, $functionname)) {
    $baseobject->$functionname($args);
} else {
    $baseobject->sendError("error", "functionality not found");
}
$getpatameter['apiresponse'] = $baseobject;
local_saveapilog($getpatameter);
echo json_encode($baseobject);

