<?php
include('../../config.php');
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');
header("HTTP/1.0 200 Successfull operation");
global $CFG, $USER, $SESSION, $API;
$events = array();
// if(is_user_logged_in()){
    // $MOODLE = new MoodleManager();
$args =$_GET;
$filtereddata = get_calendarevents($args);

if(is_array($filtereddata)){
    foreach ($filtereddata as $key => $event) {
        $eventstatusclass = "none";
        $canstart = false;
        $cancancel = false;
        $cancomplete = false;
        $canedit = false;
        $canadd = false;
        $canstartsyrvey = false;
        // if(current_user_can('plus_editevents')){
        //     $canadd = true;
        //     if($event->status == 0){
        //         $canedit = true;
        //     }
        // }
        if($event->status == 0 && $event->timestart <= time() && $event->timeend > time()){
            $canstart = true;
        }
        if($event->status != 2 && $event->status != 3){
            $cancancel = true;
        }
        if($event->status == 1){
            $cancomplete = true;
        }
        switch ($event->status) {
            case 0:
                $eventstatusclass = "planned";
                break;
            case 1:
                $eventstatusclass = "started";
                if(!$event->surveysubmitted){
                    $canstartsyrvey = true;
                }
                break;
            case 2:
                $eventstatusclass = "cancelled";
                break;
            case 3:
                $eventstatusclass = "completed";
                break;
            case 4:
                $eventstatusclass = "planned";
                break;
            case 5:
                $eventstatusclass = "claim";
                break;
            case 6:
                $eventstatusclass = "inprogress";
                break;
            default:
                // code...
                break;
        }
        $eventstatus = get_string("status_{$eventstatusclass}", "calendar");
        $event->canstart = $canstart;
        $event->eventstatus = $eventstatus;
        $event->cancancel = $cancancel;
        $event->cancomplete = $cancomplete;
        $event->canstartsyrvey = $canstartsyrvey;
        $event->canadd = $canadd;
        $event->canedit = $canedit;
        $eventname = $event->name;
        if(!empty($event->coursename)){
            $eventname = $event->coursename;
        }
        if(!empty($event->groupname)){
            $eventname .= "({$event->groupname})";
        }
        array_push($events, array(
            "start"=>date("Y-m-d\TH:i:s", $event->timestart),
            "end"=>date("Y-m-d\TH:i:s", $event->timeend),
            "duration"=>$event->duration,
            "title"=>$eventname,
            "description"=>$event->description,
            "fulldata"=>$event,
            "className"=>array('status-'.$eventstatusclass),
        ));
    }
}
echo json_encode($events);
