<?php
class LOCALAPIManager {
    private $token = ""; 
    private $currentYear = null; 
    private $currentschoolyear = 0;
    private $allinstitution = array();
    private $institution = null;
    private $institutionid = 0;
    public $status = 0; 
    public $message = "Error";
    public $data = null;
    public $code = 404;
    public $currenttime = 0;
    public $istutor = false;
    public $error = array(
        "code"=> 404,
        "title"=> "Server Error.", 
        "message"=> "server under maintenance"
    );
    function __construct() { 
        $this->currenttime = time();
        $this->code = 400;
        $this->setLocaldata();
        $this->error = array(
            "code"=> 400,
            "title"=> "Server Error..",
            "message"=> "Missing functionality"
        );
    }
    private function setLocaldata() {
        global $DB, $CFG;
        $data = getFile($CFG->dataroot. "/login.tmp");
        try {
            $finaldata = json_decode($data);
            $this->currentYear = $finaldata->currentYear;
            $this->currentschoolyear = $finaldata->currentschoolyear;
            $this->allinstitution = $finaldata->allinstitution;
            $this->institution = $finaldata->institution;
            $this->institutionid = $finaldata->institutionid;
            $this->istutor = $finaldata->istutor;
            $this->token = $finaldata->token;
        } catch (Exception $e) {
            
        }
    }
    private function sendResponse($data) {
        $this->status = 1;
        $this->message = "Success";
        $this->data = $data;
        $this->code = 200;
        $this->error = null;
    }
    public function sendError($title, $message, $code=400, $data=null) {
        $this->status = 0;
        $this->message = "Error";
        $this->data = null;
        $this->code = $code;
        $this->error = array(
            "code"=> $code,
            "title"=> $title,
            "message"=> $message,
            "data"=> $data
        );
    }
    public function getUserCredentials($args) {
        global $DB, $INSTITUTION;
        if($institutionid = $args['institutionid']){
            $INSTITUTION = (object)array("institutionid"=>$institutionid);
            $allusersdata = get_allusers();
            $response = new stdClass();
            $response->credentials = $allusersdata->credentials;
            $response->institutionId = $allusersdata->institutionId;
            $response->lastsynced = $allusersdata->lastsynced;
            $this->sendResponse($response);
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }
    public function getOfflineHomeWork($args) {
        global $DB, $INSTITUTION;
        if($institutionid = $args['institutionid']){
            $INSTITUTION = (object)array("institutionid"=>$institutionid);
            $homeworkdata = get_allhomeworks();
            $response = new stdClass();
            $response->homeworks = $homeworkdata->homeworks;
            $response->institutionId = $homeworkdata->institutionId;
            $response->lastsynced = $homeworkdata->lastsynced;
            $this->sendResponse($response);
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }
    public function getOfflineHomeWorkBlockStatus($args) {
        global $DB, $INSTITUTION;
        if($institutionid = $args['institutionid'] && $homeworkid = $args['homeworkid']){
			$this->INSTITUTION = $INSTITUTION;

            $homework = get_homeworkreport($homeworkid);
            if($homework){
                $homeqordquestionstatus = gethomeqordquestionstatus($homeworkid);
                $response = new stdClass();
                $response->blockings = $homeqordquestionstatus;
                $this->sendResponse($response);
            } else {
                $this->sendError("Invalid Request", "Homeqork not found");
            }
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }

    public function getHomeworks() {
        global $DB;
        if($this->istutor){
            $homeworkdata = get_allhomeworks();
            $response = new stdClass();
            $response->homeworks = $homeworkdata->homeworks;
            $response->institutionId = $homeworkdata->institutionId;
            $response->lastsynced = $homeworkdata->lastsynced;
            $this->sendResponse($response);
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }
    public function dataSyncStatus($args) {
        global $DB, $USER;
        $lastsynced = $args['lastsynced']?$args['lastsynced']:0;
        $synceddata = get_awaitingsynceddata("synced");
        $awaiting = array_filter($synceddata->data, function ($file) use ($lastsynced) {
            return $file->processtime > $lastsynced;
        });
        $allremainingData = array();
        $this->sendResponse(array("data"=>$allremainingData,"synceddata"=>array_values($awaiting), "updateddate"=>time()));
    }
    public function getUpdatedfiledata($args) {
        global $DB, $USER, $CFG;
        $reqid = $args['reqid'];
        try { 
            if($filedata = get_syncedfiledata($reqid)){
                $responsedata = array(
                    "filedata"=>base64_encode($filedata), 
                );
                $this->sendResponse($responsedata);
            } else {
                $this->sendError("Failed", "Please Try again later");
            }
        } catch (Exception $e) {
            $this->sendError("Failed", "Please Try again later");
        }
    }
    public function userChoiceUpdate($args) {
        if(!empty($args['element'])){
            $element = $args['element'];
            if(!isset($args['value'])){
               $_SESSION[$element]=true;
            } else {
               $_SESSION[$element]=$args['value'];
           }
            $this->sendResponse(array("success"=>true));
        } else {
            $this->sendError("Failed", "Please Try again later");
        }
    }
    public function getServerStatus($args) {
        $this->sendResponse(array("success"=>true));
    }

    public function updateEventStatus($args) {
        global  $DB, $USER, $CFG, $API;
        $args = (object)$args;
        if(save_event_update_off($args)){
            $this->sendResponse(array("status"=>1));
        } else {
            $this->sendError("Error", "Failed to update status");
        }
    }
    public function getSurveyList($args) {
        global $DB;
        $surveys = getSurveyList();
        $this->sendResponse($surveys);
    }
    public function getSurveyDetails($args) {
        global $DB, $USER;
        $args = (object) $args;
        $res = getSurveyList();
        // $this->res = $res;
        // $this->args = $args;
        $found_key = array_search($args->surveyid, array_column($res->surveys, 'id'));
        if($found_key !== false){
            $survey = $res->surveys[$found_key];
            $survey->userresponse = get_surveyresponse($USER->id, $survey->id, $args->eventid)->userresponse;
            $this->sendResponse($survey);
        } else {
            $this->sendError("Error", "Survey Not Found");
        }
    }
    public function saveSurveyResponce($args)
    {
        $args = (object) $args;
        if(save_surveyresponse($args)){
            $this->sendResponse(array("status"=>1));
        } else {
            $this->sendError("Error", "Failed to update status");
        }
    }
    public function getQuizes($args){
        if($quizdata = online_getQuizes($args)){
            $quizdata->questionstring = self::randerQuizesQuestions($quizdata);
            $this->sendResponse($quizdata);
        } else {
            $this->sendError("Error", "Failed to get Quiz details");
        }
    }
    private function randerQuizesQuestions($quizdata){
        $allquestions = $quizdata->allquestions;
        $lang = $quizdata->quiz->lang;
        $finalquestionstr = "";
        if(sizeof($allquestions) > 0){
            $finalquestionstr.='<div class="questionlist '.$lang.'" >'; 
            $i=1;
            foreach ($allquestions as $key => $question) {
                $finalquestionstr.='<div class="questionset">';
                    $finalquestionstr.='<div class="questionhead">'.$i .'.'.$question->questionTitle.'</div>';
                    if($question->type=="multianswer"){                                                     
                        foreach($question->subQuestion as $qkey => $subQuestion){
                            $stext = ""; 
                            $questionText = $subQuestion->questionText;
                            if($subQuestion->type == 'multichoiceh'){
                                $stext.='<br>';
                                foreach($subQuestion->options as $optionval){                                   
                                    $stext.='<label>                            
                                    <input type="radio"> '.$optionval->answer.'
                                    </label>&nbsp;&nbsp';                               
                                }
                                
                            }else if($subQuestion->type == 'multichoicev'){
                                $stext.='<br>';
                                foreach($subQuestion->options as $optionval){                                   
                                    $stext.='<label>                            
                                    <input type="radio"> '.$optionval->answer.'
                                    </label>
                                    </br>';                             
                                }
                                
                            
                            }else if($subQuestion->type == 'shortanswer'){                              
                                $stext.='<label>                            
                                <input type="text" value="" style="display: inline-block;width: 60px;" > 
                                </label>                        
                                <br>';
                            } else {                                
                                $stext.='<select style="display: inline-block;width: fit-content;">';
                                foreach($subQuestion->options as $optionval){
                                    $stext.='<option>'.$optionval->answer.'</option>';  
                                }
                                $stext.='</select>';        
                            }
                            $question->questionText = str_replace('{#'.($qkey+1).'}',$stext, $question->questionText);
                        }                           
                    }
                    else if($question->type=="ddwtos" || $question->type=="gapselect"){
                        $question->questionText = preg_replace('/[[[1-9]*]]/m', '<input type="text" val="" style="display: inline-block;width: 60px;">', $question->questionText);;
                    }
                    $finalquestionstr.='<div class="questionbody homeworkquiz">'.$question->questionText.'</div>';
                    $finalquestionstr.='<div class="questionanssection">';
                        if($question->type=='multichoice' || $question->type=='multiselect'){
                            if($question->isRadioButton){
                                $fieldtype='radio';
                            }else{
                                $fieldtype='checkbox';
                            }                                                   
                            foreach($question->options as $optionval ){                             
                            $finalquestionstr.='<label>                         
                            <input type="'.$fieldtype.'"> '.$optionval->answer.'
                            </label>
                            
                            <br>';  
                            }                                                       
                        }else if($question->type=="gapselect"){
                            $finalquestionstr.='<select>';
                            foreach($question->options as $optionval){
                            $finalquestionstr.='<option>'.$optionval->answer.'</option>';      
                            }
                            $finalquestionstr.='</select>';                     
                        }else if($question->type=="truefalse"){
                            foreach($question->options as $optionval ){                             
                            $finalquestionstr.='<label>                         
                            <input type="radio"> '.$optionval->answer.'
                            </label>
                            
                            <br>';  
                            }
                        }else if($question->type=="shortanswer" || $question->type=="numerical" || $question->type=="calculated"){                                                      
                            $finalquestionstr.='<label>                         
                            <input type="text" value="'.$question->rightAnswer.'" disabled> 
                            </label>                        
                            <br>';  
                        }else if($question->type=="ddwtos"){
                            foreach($question->options as $optionval ){                             
                            $finalquestionstr.='                        
                            <span class="ddwtos" style="padding: 10px;border: 1px solid;">'.$optionval->answer.'</span>';   
                            }
                        }            
                    $finalquestionstr.='</div>'; 
                        
                $finalquestionstr.='</div>';   
                $i++;
            }
            
            $finalquestionstr.='</div>';   
        } else {
            $finalquestionstr .= '<div class="alert alert-warning">'.get_string("questionnotfound", "form").'</div>';

        }
        return $finalquestionstr;
    }

}