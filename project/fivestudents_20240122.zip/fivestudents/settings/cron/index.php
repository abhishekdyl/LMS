<?php
  require_once("../../config.php");
  require_internat();
  require_login();
  $formdata = new stdClass();
  $formdata->active = optional_param("active", 0);
  $formdata->croninterval = optional_param("croninterval", 5);
  if(isset($_POST['savesettings'])){
	set_cronsetting($formdata);
    redirect("{$CFG->wwwroot}/settings/cron/");
    exit;
  }
  $cronsetting = get_cronsetting();
  if(!empty($cronsetting)){
	 $formdata->active= $cronsetting->active;
	 $formdata->croninterval= $cronsetting->croninterval;
  }
  $lastrun = get_string("lastfetched",'form');
  if(!empty($cronsetting->lastrun)){
    $lastrun = plus_dateToFrench($cronsetting->lastrun);
  }
  echo $OUTPUT->header();
  $html='';
  $html .=  '<div class="row">
            <div class="col-md-12 grid-margin transparent">
              <div class="row">';
  $html .=  '<div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">'.get_string("cronsettins", "site").'</h4>
                  <form method="post" class="forms-sample" autocomplete="off">
                    <div class="form-group row for_lessons">
                      <label for="active" class="col-sm-2 col-form-label text-right"><input type="checkbox" value="1" '.($formdata->active == 1?' checked="checked" ':'').' id="active" name="active" /></label>
                      <div class="col-sm-10">
                        <label for="active" class="col-form-label">'.get_string("enabled", "form").'</label>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="croninterval" class="col-sm-2 col-form-label">'.get_string("croninterval", "form").' *</label>
                      <div class="col-sm-10">
                        <input type="number" name="croninterval" class="form-control" id="croninterval" value="'.$formdata->croninterval.'">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-12 col-form-label">'.get_string("lastrun", "form").': '.$lastrun.'</label>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-12 col-form-label">'.get_string("datapath", "form").': '.$CFG->dataroot.'</label>
                    </div>
                    <button type="submit" name="savesettings" class="btn btn-primary mr-2">'.get_string("save", "form").'</button>
                  </form>
                </div>
              </div>
            </div>';
  $html .=  '</div>
            </div>
          </div>';
  echo $html;
  echo $OUTPUT->footer();