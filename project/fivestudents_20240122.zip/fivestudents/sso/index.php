<?php
  require_once("../config.php");
  $url = optional_param("url", "");
  require_internat();
  $reqdata = array();
  $response = $API->call("generateSsoToken",$reqdata);
  $ssourl = "{$CFG->wproot}/localsso?token={$response->data->uniqueKey}&key={$USER->id}&url={$url}";
  redirect($ssourl);