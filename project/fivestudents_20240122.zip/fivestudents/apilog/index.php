<?php
  require_once("../config.php");
  require_login();
  $OUTPUT->loadjquery();
  $logdata = local_getapilog();
  echo $OUTPUT->header();
  $html = '';
  // $html .= '<pre>'.print_r($logdata, true).'</pre>';
  $html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <p class="card-title mb-0">API LOG <span class="badge"></span></p>
                  <div class="text-right">
                  </div>
                  <br/>
                  <div class="table-responsive">
                    <table id="userlist" class="table plus_local_datatable table-borderless">
                      <thead>
                        <tr>
                          <th class="border-bottom pb-2">Sl. No</th>
                          <th class="border-bottom pb-2">logtime</th>
                          <th class="border-bottom pb-2">wsfunction</th>
                          <th class="border-bottom pb-2">arguments</th>
                          <th class="border-bottom pb-2">Response Status</th>
                          <th class="border-bottom pb-2">Status</th>
                          <th class="border-bottom pb-2">message</th>
                          <th class="border-bottom pb-2">response</th>
                        </tr>
                      </thead>
                      <tbody>';
  if(is_array($logdata) && sizeof($logdata)){
    $logdata = array_reverse($logdata);
    foreach ($logdata as $key => $log) {
      $log = (object) $log;
      $html .='<tr>
        <td>'.($key+1).'</td>
        <td>'.(isset($log->logtime)?plus_dateToFrench($log->logtime):'').'</td>
        <td>'.(isset($log->wsfunction)?$log->wsfunction:"").'</td>
        <td>'.(isset($log->wsargs)?json_encode($log->wsargs):'').'</td>
        <td>'.((isset($log->apiresponse) && isset($log->apiresponse->code))?$log->apiresponse->code:'').'</td>
        <td>'.((isset($log->apiresponse) && isset($log->apiresponse->status))?($log->apiresponse->status?"Sucess":"failed"):'').'</td>
        <td>'.((isset($log->apiresponse) && isset($log->apiresponse->message))?$log->apiresponse->message:'').'</td>
        <td>'.((isset($log->apiresponse) && isset($log->apiresponse->data))?json_encode($log->apiresponse->data):'').'</td>
      </tr>';
    }
  }
  $html .='
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  $html .='';
  echo $html;
  echo $OUTPUT->footer();
