<?php
  require_once("../config.php");
  require_login();
  $syncnow = optional_param("syncnow", 0);
  if($syncnow){
    syncAllUsers();
    redirect("{$CFG->wwwroot}/users");
  }
  $OUTPUT->loadjquery();
  $usersdata = get_allusers();
  $lastsynced = get_string("lastfetched",'form');
  if(is_object($usersdata) && !empty($usersdata->lastsynced)){
    $lastsynced = plus_dateToFrench($usersdata->lastsynced);
  }
  echo $OUTPUT->header();
  $html = '';
  // $html = '<pre>'.print_r($usersdata, true).'</pre>';
  $html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <p class="card-title mb-0">'.get_string("users", "site").' <span class="badge">'.get_string("lastsynced",'site').': '.$lastsynced.'</span></p>
                  <div class="text-right">
                  '.(has_internet()?'<a class="btn btn-primary" href="'.$CFG->wwwroot.'/users/?syncnow=1">'.get_string("syncnow",'site').'</a>':'').'
                  </div>
                  <br/>
                  <div class="table-responsive">
                    <table id="userlist" class="table plus_local_datatable table-borderless">
                      <thead>
                        <tr>
                          <th class="pl-0  pb-2 border-bottom">ID</th>
                          <th class="border-bottom pb-2">'.get_string("username", "student").'</th>
                          <th class="border-bottom pb-2">'.get_string("firstname", "form").'</th>
                          <th class="border-bottom pb-2">'.get_string("lastname", "form").'</th>
                          <th class="border-bottom pb-2">'.get_string("chartname", "form").'</th>
                          <th class="border-bottom pb-2">'.get_string("level", "form").'</th>
                          <th class="border-bottom pb-2">'.get_string("groups", "site").'</th>
                        </tr>
                      </thead>
                      <tbody>';
  if(is_object($usersdata) && is_array($usersdata->credentials)){
    foreach ($usersdata->credentials as $key => $user) {
      $html .='<tr>
        <td>'.$user->id.'</td>
        <td>'.$user->username.'</td>
        <td>'.$user->firstname.'</td>
        <td>'.$user->lastname.'</td>
        <td>'.$user->charname.'</td>
        <td>'.$user->gradeName.'</td>
        <td>'.$user->groups.'</td>
      </tr>';
    }
  }
  $html .='
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  $html .='';
  echo $html;
  echo $OUTPUT->footer();