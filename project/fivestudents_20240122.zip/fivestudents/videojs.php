<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>video player</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <style>


video::-webkit-media-controls {

/*display: none;
} 


 

    </style>

</head>
<body>
    

<video id="myVideo" controls="true" controlslist="download" autoplay="autoplay" muted >
    <source src="Kaavaalaa.mp4" type="video/mp4">
</video>


<script>
    
$(document).ready(function() {
    var video = document.getElementById("myVideo").controls = false;
    var isEditable = document.createElement('input');
    isEditable.contentEditable = true;
    var browserEditable = isEditable.contentEditable === true;
    if (!browserEditable) {
        $('video').removeAttr('controls');
        $('video').removeAttr('controlslist');
        $('video').removeAttr('download');
    }
   


    video.addEventListener("click", function() {
        if (video.paused) {
            video.play();
        } else {
            video.pause();
        }
    });




$('video::-webkit-media-controls-picture-in-picture-button').css('display', 'none');
$('video::-webkit-media-controls-enclosure').css('display', 'none');
$('video::-webkit-media-controls-panel').css('display', 'none');
$('video::-webkit-media-controls-playback-rate-button').css('display', 'none');
$('video::-webkit-media-controls-download-button').css('display', 'none');




});






</script>

</body>
</html>