<?php
unset($CFG);  // Ignore this line
global $CFG;  // This is necessary here for PHPUnit execution
$CFG = new stdClass();
$CFG->wwwroot = "https://qaweb.fivestudents.com/fivestudents";
$CFG->apiroot = "https://portal.fivestudents.com";
$CFG->wproot = "https://plus.fivestudents.com";
$CFG->key = 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';
$CFG->syncapicount = 5000;
error_reporting(0);
require_once("setup.php");