<?php
function require_login() {
	global $CFG; 
	if(!(isset($_SESSION['loginuser']) && !empty($_SESSION['loginuser']))){
		redirect("{$CFG->wwwroot}/login/", "Please login to view this page", "info");
	}
}
function has_internet() {
	global $CFG;
	return $CFG->internetstatus;
}
function require_internat() {
	global $CFG;
	if(!has_internet()){
		redirect("{$CFG->wwwroot}", "Please connect to internet", "warning");
	}
}
function isloggedin() {
	if(isset($_SESSION['loginuser']) && !empty($_SESSION['loginuser'])){
		return true;
	}
}
function optional_param($parname, $default=null) {
    // POST has precedence.
    if (isset($_POST[$parname])) {
        $param = $_POST[$parname];
    } else if (isset($_GET[$parname])) {
        $param = $_GET[$parname];
    } else {
        return $default;
    } 
    return $param;
}

function authenticate_user_login($username, $password) {
	global $API, $USER, $SESSION,$CFG, $INSTITUTION;
	if(has_internet()){
		$reqdata = array(
			"username"=>$username,
	        "password"=>$password,
	        "logintype"=>"tutor"
	    );
		$response = $API->call("login",$reqdata);
		if($response->code == 200) {
			$SESSION['user'] = $response->data->userDetails;
			$SESSION['token'] = $response->data->token;
			$SESSION['userdata'] = $response->data;
			$SESSION['institution'] = $response->data->institution;
			$USER = $response->data->userDetails;
			$INSTITUTION = $response->data->institution;
			saveFileTo("dataroot", "/", md5("lastinstitution").".tmp", $response->data->institution);
			saveFileTo("userroot", "/", "login_{$USER->id}.tmp", $response->data);
			$_SESSION['loginuser'] = $USER;
			$_SESSION['logintoken'] = $SESSION['token'];
			$_SESSION['userdata'] = $SESSION['userdata'];
			$_SESSION['institution'] = $SESSION['institution'];
			initialsync();
			redirect("{$CFG->wwwroot}/dashboard");
		}
		return false;
	} else {
		local_login($username, $password);
		return false;
	}
}
function local_login($username, $password){
	global $CFG, $INSTITUTION;
	if(!isset($INSTITUTION->institutionid) || empty($INSTITUTION->institutionid)){
		redirect("{$CFG->wwwroot}/login", "Please login as tutor and sync credentials before using it offline", "warning");
	}
	$usersdata = get_allusers();
	$user_key = array_search($username, array_column($usersdata->credentials, 'username'));
	if($user_key !== false){
		$user = $usersdata->credentials[$user_key];
		if($user->password == md5($password)){
			$SESSION['user'] = $user;
			$SESSION['token'] = "localtoken";
			$USER = $user;
			$_SESSION['loginuser'] = $USER;
			$_SESSION['logintoken'] = $SESSION['token'];
			redirect("{$CFG->wwwroot}/dashboard");
			exit;
		}
	}
	redirect("{$CFG->wwwroot}/login", "Invalid credentials", 'error');
	exit;
}
function syncAllUsers() {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	$reqdata = array();
	$response = $API->call("getUserCredentials",$reqdata);
	if($response->code == 200) {
		saveFileTo("institutionroot", "/", $CFG->userdata, $response->data);
	}
}
function my_encrypt($data) {
	global $CFG;
	if(empty($key)){
		$key = $CFG->key;
	}
    $encryption_key = base64_decode($key);
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}
function my_decrypt($data) {
	global $CFG;
	if(empty($key)){
		$key = $CFG->key;
	}
    $encryption_key = base64_decode($key);
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
}
function getdirpath($region)
{
	global $CFG, $USER, $INSTITUTION;
	$finalpath = $CFG->dataroot;
	switch ($region) {
		case 'dataroot':
			$finalpath = $CFG->dataroot;
		break;
		case 'syncdataroot':
			$finalpath = $CFG->syncdataroot;
		break;
		case 'localdataroot':
			$finalpath = $CFG->localdataroot;
		break;
		case 'userroot':
			$subpath = md5("user_{$USER->id}");
			$finalpath = "{$CFG->dataroot}/{$subpath}";
		break;
		case 'institutionroot':
			$subpath = md5("institution_{$INSTITUTION->institutionid}");
			$finalpath = "{$CFG->dataroot}/{$subpath}";
		break;
		default:
			$finalpath = $CFG->dataroot;
		break;
	}
	if(!is_dir($finalpath)) {
	    mkdir($finalpath, 0777, true);
	}
	return $finalpath;
}
function saveFileTo($region, $path, $filename, $data) {
	$finalpath = getdirpath($region);
	if(!is_string($data)){
		$data = json_encode($data);
	}
	$encrypted_code = my_encrypt($data);
	$finalfilepath = "{$finalpath}{$path}{$filename}"; 
	checkdirpath("{$finalpath}{$path}");
	file_put_contents($finalfilepath, $encrypted_code);
	return true;
}
function saveFile($path, $filename, $data) {
	global $CFG;
	if(!is_dir($path)) {
	    mkdir($path, 0777, true);
	}
	if(!is_string($data)){
		$data = json_encode($data);
	}
	$encrypted_code = my_encrypt($data); 
	file_put_contents($path.'/'.$filename, $encrypted_code);
	return true;
}
function saveOriginalFile($path, $filename, $data) {
	global $CFG;
	if(!is_dir($path)) {
	    mkdir($path, 0777, true);
	}
	if(!is_string($data)){
		$data = json_encode($data);
	}
	// $encrypted_code = my_encrypt($data); 
	file_put_contents($path.'/'.$filename, $data);
	return true;
}
function getFileForm($region, $path, $filename) {
	global $CFG;
	$finalpath = getdirpath($region);
	$finalfilepath = "{$finalpath}{$path}{$filename}"; 
	if(file_exists($finalfilepath)){
		$encrypted_code = file_get_contents($finalfilepath);
		$decrypted_code = my_decrypt($encrypted_code);//Decrypt the encrypted code.
		return $decrypted_code;
	}
}
function getFile($path) {
	global $CFG;
	if(file_exists($path)){
		$encrypted_code = file_get_contents($path);
		$decrypted_code = my_decrypt($encrypted_code);//Decrypt the encrypted code.
		return $decrypted_code;
	}
}
function get_allusers() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->userdata);

	if($filedata){
		$allusers = json_decode($filedata);
	} else {
		$allusers = new stdClass();
		$allusers->credentials = array();
		$allusers->lastsynced = 0;
		$allusers->institutionId = 0;
	}
	return $allusers;
}
function syncAllHomeworks() {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	$reqdata = array();
	$response = $API->call("getOfflineHomeWork",$reqdata);
	if($response->code == 200) {
		saveFileTo("institutionroot", "/", $CFG->homeworkdata, $response->data);
	}
}
function get_allhomeworks() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->homeworkdata);
	if($filedata){
		$allusers = json_decode($filedata);
	} else {
		$allusers = new stdClass();
		$allusers->homeworks = array();
		$allusers->lastsynced = 0;
		$allusers->institutionId = 0;
	}
	return $allusers;
}
function syncAllGroups() {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	$reqdata = array();
	$response = $API->call("getOfflineGroups",$reqdata);
	if($response->code == 200) {
		saveFileTo("institutionroot", "/", "groupsdata.tmp", $response->data);
	}
}
function get_allgroups() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", "groupsdata.tmp");
	if($filedata){
		$allusers = json_decode($filedata);
	} else {
		$allusers = new stdClass();
		$allusers->groups = array();
		$allusers->lastsynced = 0;
		$allusers->institutionId = 0;
	}
	return $allusers;
}
function get_localdashdata($args){
	global $CFG;
	$dashdata = new stdClass();
	$dashdata->grades = array();
    $homeworkdata = array("notstarted"=>array("count"=>0, "total"=>0, "percent"=>0), "notpassed"=>array("count"=>0, "total"=>0, "percent"=>0), "notcompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "completed"=>array("count"=>0, "total"=>0, "percent"=>0),"latecompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "passed"=>array("count"=>0, "total"=>0, "percent"=>0), "totalquizcompleted"=>0);
	$allhomework = get_allhomeworks();
	$usersdata = get_allusers();
	$alllocaldata = get_alllocaldata();
	$totalhomeworkstudent = 0;
	switch ($args->filtertype) {
        case 1:
            $args->fromdate = date("Y-m-d");
            $args->todate = date("Y-m-d");
            break;
        case 2:
            $startdate = strtotime("-1 day");
            $args->fromdate = date("Y-m-d", $startdate);
            $args->todate = date("Y-m-d", $startdate);
            break;
        case 3:
            $startdate = strtotime(date("01 F Y"));
            $enddate = strtotime(date("t F Y"));
            $args->fromdate = date("Y-m-d", $startdate);
            $args->todate = date("Y-m-d", $enddate);
            break;
    }
	$args->fromdatestamp = strtotime($args->fromdate);
	$args->fromdatestr = date("d F Y H:i:s A", $args->fromdatestamp);
	$args->todatestamp = strtotime("+1 day", strtotime($args->todate));
	$args->todatestr = date("d F Y H:i:s A", $args->todatestamp);
	$totalquizcompleted = 0;
    foreach ($alllocaldata as $key => $attempt) {
    	$q = json_decode(getFile("{$CFG->syncdataroot}/$attempt"));
    	if(is_object($q)){
	        if($q->submissiontime < $args->fromdatestamp || $q->submissiontime < $args->todatestamp){
	            continue;
	        }
			$totalquizcompleted ++;
    	}
    }
	// echo "<pre>\n\n\n\n\n\n";
	// print_r($args);
	// echo "</pre>";
	// die;
	foreach ($allhomework->homeworks as $key => $homework) {
		$alluser = array_values(array_filter($usersdata->credentials, function ($user) use ($homework) {
		    return in_array($homework->groupid, $user->groupids);
		}));
		$filenames = array_map(function($user) use ($homework)
		{
		    return "quiz_{$homework->quiz}_userid_{$user->id}_";
		}, $alluser);
		$attempted = array_filter($alllocaldata, function ($datafile) use ($filenames)
		{
			$exist = false;
			foreach ($filenames as $file) {
				if(strpos($datafile, $file)){$exist=true; break;}
			}
		    return $exist;
		});
		$homework->totaluser = sizeof($alluser);
	    $started = 0;
	    $completed = 0;
	    $completed = 0;
	    $latecompleted = 0;
	    $passed = 0;
	    foreach ($attempted as $key => $attempt) {
	    	$q = json_decode(getFile("{$CFG->syncdataroot}/$attempt"));
	    	if(is_object($q)){
		        // if($q->submissiontime < $args->fromdatestamp || $q->submissiontime < $args->todatestamp){
		        //     continue;
		        // }
	        	$started++;
	        	if($q->isfinished){
			        $completed++;
			        if(isset($q->qasumgrades) && (($q->qasumgrades/$homework->qsumgrades)*$homework->gigrademax >= $homework->gigradepass)){
			            $passed++;
			        }
			        if($q->submissiontime>$homework->duedate){
			            $latecompleted++;
			        }
	        	}
	    	}
	    }
        $totalstudent = $homework->totaluser;
        $notstarted = $totalstudent-$started;
        $totalhomeworkstudent += $totalstudent;
        $homeworkdata['passed']['total']+=$completed;
        $homeworkdata['notpassed']['total']+=$completed;
        $homeworkdata['completed']['total']+=$totalstudent;
        $homeworkdata['latecompleted']['total']+=$completed;
        $homeworkdata['notstarted']['total']+=$totalstudent;
        $homeworkdata['notcompleted']['total']+=$totalstudent;
        $homeworkdata['passed']['count']+=$passed;
        $homeworkdata['completed']['count']+=$completed;
        $homeworkdata['latecompleted']['count']+=$latecompleted;
        $homeworkdata['notstarted']['count']+=$notstarted;
        $homeworkdata['notcompleted']['count']+= ($totalstudent - ($notstarted+$completed));
        $homeworkdata['notpassed']['count']=$homeworkdata['completed']['count']-$homeworkdata['passed']['count'];

	}
    foreach ($homeworkdata as $key => $value) {
        if(empty($homeworkdata[$key]['count']) || empty($homeworkdata[$key]['total'])){ continue; }
        $homeworkdata[$key]['percent'] = number_format($homeworkdata[$key]['count']/$homeworkdata[$key]['total']*100, 2);
    }

    $homeworkdata['totalquizcompleted']=$totalquizcompleted;

	$dashdata->homeworkkpi = json_decode(json_encode($homeworkdata));
	return $dashdata;
}
function get_dashdata($args) {
	global $CFG, $API;
	if(has_internet()){
		$dashdata = $API->call("Dashboard",$args);
		if($dashdata->status =1){
			saveFileTo("userroot", "/", "dashdata.tmp", $dashdata->data);
		}
		if($filedata = getFileForm("userroot", "/", "dashdata.tmp")){
			$dashdata = json_decode($filedata);
		} else {
			$dashdata = new stdClass();
			$dashdata->grades = array();
			$dashdata->homeworkkpi = json_decode(json_encode(array("notstarted"=>array("count"=>0, "total"=>0, "percent"=>0), "notpassed"=>array("count"=>0, "total"=>0, "percent"=>0), "notcompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "completed"=>array("count"=>0, "total"=>0, "percent"=>0),"latecompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "passed"=>array("count"=>0, "total"=>0, "percent"=>0), "totalquizcompleted"=>0)));
		}
	} else {
		$dashdata = get_localdashdata($args);
	}
	// if($filedata = getFileForm("userroot", "/", "dashdata.tmp")){
	// 	$dashdata = json_decode($filedata);
	// } else {
	// 	$dashdata = new stdClass();
	// 	$dashdata->grades = array();
	// 	$dashdata->homeworkkpi = json_decode(json_encode(array("notstarted"=>array("count"=>0, "total"=>0, "percent"=>0), "notpassed"=>array("count"=>0, "total"=>0, "percent"=>0), "notcompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "completed"=>array("count"=>0, "total"=>0, "percent"=>0),"latecompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "passed"=>array("count"=>0, "total"=>0, "percent"=>0), "totalquizcompleted"=>0)));
	// }
	return $dashdata;
}
function fetch_awaitingsynceddata() {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	$reqdata = array(
		"lastsynced"=>0
	);
	$response = $API->call("dataSyncStatus",$reqdata);
	if($response->code == 200) {
		saveFileTo("dataroot", "/syncdata/", "awaitingsynceddata.tmp", $response->data);
	}
}
function get_awaitingsynceddata($from='') {
	global $CFG;
	$filedata = getFileForm("dataroot", "/syncdata/","{$from}synceddata.tmp");
	if($filedata){
		$synceddata = json_decode($filedata);
	} else {
		$synceddata = new stdClass();
		$synceddata->data = array();
		$synceddata->updateddate = 0;
	}
	return $synceddata;
}
function get_logintoken() {
	return isset($_SESSION['logintoken'])?$_SESSION['logintoken']:null;
}
function redirect($url, $message="", $type="info") {
	global $OUTPUT;
	$_SESSION['redirecturl'] = $url;
	if(!empty($message)){
		$_SESSION['redirectmessage'] = $message;
		$_SESSION['redirecttype'] = $type;
	}
	if(!headers_sent()){
	    $redirectby = 'Local';
        @header("X-Redirect-By: $redirectby");

        // 302 might not work for POST requests, 303 is ignored by obsolete clients.
        @header($_SERVER['SERVER_PROTOCOL'] . ' 303 See Other');
        @header('Location: '.$url);
        exit;
	} else {
        echo $OUTPUT->redirect_message($url);
	}
}
function timestamp_to_date($date, $format="d F Y H:i A") {
	if(intval($date) !=0 ){
		$datetext = date($format,$date);
		return $datetext;
	}
	return $date;
}
function base_init() {
	global $API, $USER, $SESSION, $LOCAL, $INSTITUTION, $OUTPUT;
	$SESSION = array();
	$SESSION['user'] = isset($_SESSION['loginuser'])?$_SESSION['loginuser']:null;
	$SESSION['token'] = isset($_SESSION['logintoken'])?$_SESSION['logintoken']:null;
	$SESSION['userdata'] = isset($_SESSION['userdata'])?$_SESSION['userdata']:null;
	$SESSION['institution'] = isset($_SESSION['institution'])?$_SESSION['institution']:null;
	$USER = $SESSION['user'];
	$INSTITUTION = $SESSION['institution'];
	$OUTPUT = new outputRenderer();
	$API = new APIManager();
	prepareLocalData();
	checkcronstatus();
}
function get_localdata() {
	global $USER, $CFG, $LOCAL, $INSTITUTION;
	$d = getFileForm("dataroot", "/", md5("lastinstitution").".tmp");
	if(!empty($d)){
		$INSTITUTION = json_decode($d);
	}
	$filedata = json_decode(getFile($CFG->dataroot."/access.tmp"));
	if(is_object($filedata)){
		return $filedata;
	} else {
		$filedata = new stdClass();
		$filedata->syncedfiles = array();
		$filedata->datalastsynced = "never";
		return $filedata;
	}
}
function prepareLocalData() {
	global $USER, $CFG, $LOCAL;
	try {
		$LOCAL = get_localdata();
	} catch (Exception $e) {
		$LOCAL = new stdClass();
		$LOCAL->syncedfiles = array();
	}
}
function getDashboardData($formdata) {
	$data = new stdClass();
	$data->homeworkdata = get_allhomeworks();
	$data->usersdata = get_allusers();
	$data->awaitingsyncdata = get_allawaitingsync();
	$data->dashdata = get_dashdata($formdata);
	return $data;
}
function fullname($user=null){
	global $USER;
	$name = array();
	if(empty($user)){
		$user = $USER;
	}
	if(!empty($user->firstname)){array_push($name, $user->firstname);}
	if(!empty($user->lastname)){array_push($name, $user->lastname);}
	return implode(" ", $name);
}
function scanAllDir($dir, $readdir=false) {
	$result = [];
	foreach(scandir($dir) as $filename) {
	    if ($filename[0] === '.') continue;
	    $filePath = $dir . '/' . $filename;
	    if (is_dir($filePath)) {
			foreach (scanAllDir($filePath) as $childFilename) {
				$result[] = $filename . '/' . $childFilename;
			}
	    } else {
	      $result[] = $filename;
	    }
	}
	return $result;
}
function get_alllocaldata() {
	global $CFG, $LOCAL;
	return scanAllDir($CFG->syncdataroot, true);
}

function get_allawaitingsync() {
	global $CFG, $LOCAL;
	$syncedfiles = get_alllocaldata();
	$synced = $LOCAL->syncedfiles;
	$lastsynced = $LOCAL->datalastsynced?$LOCAL->datalastsynced:"never";
	$awaiting = array_filter($syncedfiles, function ($file) use ($synced) {
	    return !in_array($file, $synced);
	});
	$syncdata = new stdClass();
	$syncdata->awaiting = $awaiting;
	$syncdata->synced = $synced;
	$syncdata->awaitingcount = sizeof($syncdata->awaiting);
	$syncdata->syncedcount = sizeof($syncdata->synced);
	$syncdata->total = $syncdata->awaitingcount + $syncdata->syncedcount;
	$syncdata->lastsynced = $lastsynced;
	return $syncdata;
	
	// $attemptdata = json_decode(getFile("{$CFG->syncdataroot}/$path"));
}
function get_string($key, $page="") {
	global $LANGUAGESTRINGS, $CURRENTLANG;
	$lang = $CURRENTLANG;
	if(isset($LANGUAGESTRINGS[$lang])){
		$stringarray = $LANGUAGESTRINGS[$lang];
		$finalkey = (!empty($page)?$page."_":"").$key;
		if(isset($stringarray[$finalkey])){
			return $stringarray[$finalkey];
		} else {
			return $lang.'['.$finalkey.']';
		}
	} else {
		return $lang.'['.$key.']';
	}
}
function get_qsparameter($allparams) {
	$qsarray = array();
	if(is_object($allparams)){$allparams = (array)$allparams;}
	if(is_array($allparams)){
		foreach ($allparams as $key => $param) {
			if(is_array($param)){
				foreach($param as $p){
					array_push($qsarray, $key."[]=$p");
				}
			} else {
				array_push($qsarray, "$key=$param");
			}	
		}
	}
    return implode("&", $qsarray);
}
function get_allparameter() {
    return $_GET;
}
function getpageurl($pageurl = null, $args = null) {
  global $CFG;
  if(empty($pageurl)){
  	$pageurl = $CFG->wwwroot;
  }
  if(empty($args)){
  	$args = array();
  }
  return $pageurl.'?'. get_qsparameter($args);
}
function get_current_pageurl()
{
	global $CFG;
	return (isset($_SERVER['SCRIPT_NAME']) && !empty($_SERVER['SCRIPT_NAME']))?$_SERVER['SCRIPT_NAME']:$CFG->wwwroot;
} 
function check_validateUserResponse($content) {
	if(is_string($content)){
		$content = json_decode($content);
	}
	$errors = array();
	if(!is_object($content)){
		array_push($errors, "Invalid Data format");
	} else {
		$allrequiredcheck = array("userid", "devicetoken", "devicename", "attempt", "quizid", "submissiondate", "submissiontime", "questions", "isAttempted", "isfinished");
		$notemptycheck = array("userid", "devicetoken", "devicename", "attempt", "quizid", "submissiondate", "submissiontime", "questions", "isAttempted");
		foreach ($allrequiredcheck as $key => $requiredfield) {
			if(!isset($content->$requiredfield)){
				array_push($errors, "Missing required key {$requiredfield}");
			} else if(in_array($requiredfield, $notemptycheck) && empty($content->$requiredfield))
				array_push($errors, "{$requiredfield} should not be empty.");
		}
	}
	if(sizeof($errors) == 0){
		return true;
	}
	return $errors;
}
function get_homeworkreport($homeworkid) {
	GLOBAL $CFG;
	$homeowrk = null;
	$homeworkdata = get_allhomeworks()->homeworks;
	$found_key = array_search($homeworkid, array_column((array)$homeworkdata, 'id'));
	if($found_key !== false){
		$homeowrk = $homeworkdata[$found_key];
		$allusers = get_allusers()->credentials;
		$groupid = $homeowrk->groupid;
		$users = array_filter($allusers, function ($user) use ($groupid) {
		    return in_array($groupid, $user->groupids);
		});
		
		$syncedfiles = get_alllocaldata();
		foreach ($users as $key => $user){
			$filename = "quiz_{$homeowrk->quiz}_userid_{$user->id}";
			$userdata = array_filter($syncedfiles, function ($path) use ($filename) {
		    		return strpos($path, $filename) !== false;
			});
			if(sizeof($userdata)> 0){
				$user->attemptdata = json_decode(getFile("{$CFG->syncdataroot}/".array_pop($userdata)));
				// echo json_encode($user->attemptdata);
				// die;
			} else {
				$user->attemptdata = null;
			}
		}
        $homeowrk->users = $users;
	}
	return $homeowrk;
}
function syncAlluserdata($syncnow) {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	try {
		$data = get_allawaitingsync();
		if($data->awaitingcount){
			$counter = 0;
			$allattemptdata = array();
			$awaiting = $data->awaiting;
			foreach ($awaiting as $key => $attempt) {
				if($syncnow != "all" && $syncnow != md5($attempt)){
					continue;
				}
				if($counter >= $CFG->syncapicount){break;}
				$attemptdata = getFile("{$CFG->syncdataroot}/$attempt");
				array_push($allattemptdata, array("file"=>$attempt, "data"=>$attemptdata));
				$counter++;
			}
			$reqdata = array(
				"alldata"=>$allattemptdata
			);
			$response = $API->call("syncLocalData",$reqdata);
			if($response->code == 200) {
				if(is_array($response->data->passed)){
					foreach ($response->data->passed as $key => $attempt) {
						datasyncedsuccess($attempt->file);
					}
				}
			}
		}
	} catch (Exception $e) {
	}
}
function datasyncedsuccess($filepath) {
	global $CFG;
	$data = get_localdata();
	if(is_array($data->syncedfiles)){
		array_push($data->syncedfiles, $filepath);
		$data->datalastsynced = time();
		saveFileTo("dataroot", "/", "access.tmp", json_encode($data));		
	}
}
function syncmoduledata($updatedata) {
	global $API, $CFG;
	require_internat();
	$reqdata = array(
		"reqid"=>$updatedata->id
	);
	$response = $API->call("getUpdatedfiledata",$reqdata);
	if(is_object($response) && $response->code == 200 && $response->data->filedata) {
		saveFileTo("dataroot", "/syncdata/", md5("data_{$updatedata->id}").".tmp", base64_decode($response->data->filedata));
		// saveOriginalFile($CFG->localorigdataroot, "{$updatedata->id}.zip", base64_decode($response->data->filedata));
		return addtolocalsynceddata($updatedata);
	}
}
function addtolocalsynceddata($updatedata) {
	global $API, $CFG;
	$synceddata = get_awaitingsynceddata("synced");
	if(is_array($synceddata->data)){
		$found_key = array_search($updatedata->id, array_column($synceddata->data, 'id'));
		if($found_key !== false){
			$synceddata->data[$found_key] = $updatedata;
		} else {
			array_push($synceddata->data, $updatedata);
		}
		if($updatedata->processtime > $synceddata->updateddate){
			$synceddata->updateddate = $updatedata->processtime;
		}
		saveFileTo("dataroot", "/syncdata/", "syncedsynceddata.tmp", json_encode($synceddata));
		return true;
	}
}
function updatehomeqordquestionstatus($homeworkid, $questionid, $status=0) {
	global $API, $USER, $SESSION, $CFG;
	$hmstatus = getquestionblockingstatus();
	if(!isset($hmstatus[$homeworkid])){
		$hmstatus[$homeworkid] = new stdClass();
	}
	$questionsstatus= (object)$hmstatus[$homeworkid];
	$questionsstatus->$questionid = $status;
	$hmstatus[$homeworkid] = $questionsstatus;
	saveFileTo("institutionroot", "/", "homeworkquestionstatus.tmp", $hmstatus);
	return true;
}
function gethomeqordquestionstatus($homeworkid) {
	global $API, $USER, $SESSION, $CFG;
	$hmstatus = getquestionblockingstatus();
	if(!isset($hmstatus[$homeworkid])){
		$hmstatus[$homeworkid] = new stdClass();
	}
	return $hmstatus[$homeworkid];
}
function getquestionblockingstatus() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", "homeworkquestionstatus.tmp");
	if($filedata){
		$data = json_decode($filedata, true);
	} else {
		$data = array();
	}
	return $data;
}
function get_group($groupid)
{
	$groupdata = get_allgroups();
	$group_key = array_search($groupid, array_column($groupdata->groups, 'id'));
	if($group_key !== false){
		$group = $groupdata->groups[$group_key];
		return $group;
	}
	return false;
}
function online_GetGroupDetailsById($groupid, $currentschoolyear=0) {
	global $API;
	$APIRES = $API->call("GetGroupDetailsById", array("id"=>$groupid, "currentschoolyear"=>$currentschoolyear));
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_GetGroupById($groupid) {
	global $API;
	$APIRES = $API->call("GetGroupById", array("id"=>$groupid));
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_GetCoursesModeDetails($ids) {
	global $API;
	$APIRES = $API->call("GetCoursesModeDetails", array("ids"=>$ids));
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_GetHomeWorkById($id) {
	global $API;
	$APIRES = $API->call("GetHomeWorkById", array("id"=>$id));
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_SaveHomeWork($formdata)
{
	global $API;

	$APIRES = $API->call("SaveHomeWork", $formdata);
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_getAllSchoolyear()
{
	global $API;
	$APIRES = $API->call("getAllSchoolyear", array());
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_getclassProfileFilter($formdata)
{
	global $API;
	$APIRES = $API->call("getclassProfileFilter", $formdata);
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function online_getclassProfileReport($formdata)
{
	global $API;
	$APIRES = $API->call("getclassProfileReport", $formdata);
	if($APIRES->code == 200){
		return $APIRES->data;
	}
	return null;
}
function local_getapilog(){
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->apilogdata);
	if($filedata){
		$filedata = json_decode($filedata);
	} else {
		$filedata = array();
	}
	return $filedata;
}
function local_saveapilog($request){
	global $API, $USER, $SESSION, $CFG;
	$request = (array)$request;
	$logdata = local_getapilog();
	if(empty($logdata)){
		$logdata = array();
	}
	$request['logtime'] = time();
	array_push($logdata, $request);
	saveFileTo("institutionroot", "/", $CFG->apilogdata, $logdata);
	return true;	
}
function get_syncedfiledata($fileid)
{
	return getFileForm("dataroot", "/syncdata/", md5("data_{$fileid}").".tmp");
}
function syncAllDevices() {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	$reqdata = array();
	$response = $API->call("getOfflineGroups",$reqdata);
	if($response->code == 200) {
		saveFileTo("institutionroot", "/", $CFG->devicelist, $response->data);
	}
}
function get_alldevices() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->devicelist);
	if($filedata){
		$allusers = json_decode($filedata);
	} else {
		$allusers = new stdClass();
		$allusers->groups = array();
		$allusers->lastsynced = 0;
		$allusers->institutionId = 0;
	}
	return $allusers;
}
function syncAlldevicelist() {
	global $API, $USER, $SESSION, $CFG;
	require_internat();
	$reqdata = array();
	$response = $API->call("getDeviceKeys",$reqdata);
	if($response->code == 200) {
		saveFileTo("institutionroot", "/", $CFG->devicekeys, $response->data);
	}
}
function get_alldevicelist() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->devicekeys);
	if($filedata){
		$devicelist = json_decode($filedata);
	} else {
		$devicelist = new stdClass();
		$devicelist->deviceslist = array();
		$devicelist->allowedkeys = 0;
	}
	return $devicelist;
}
function initialsync() {
	syncAllGroups();
	syncAlldevicelist();
	syncAllHomeworks();
	syncAllUsers();
	syncAlluserdata('all');
}
function get_cronsetting() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->cronsetting);
	if($filedata){
		$finaldata = json_decode($filedata);
	} 
	if(empty($finaldata)){
		$finaldata = new stdClass();
		$finaldata->active = false;
		$finaldata->croninterval = 5;
		$finaldata->lastrun = 0;
	}
	return $finaldata;
}
function set_cronsetting($args) {
	global $CFG;
	$setting = get_cronsetting();
	$setting->active = $args->active;
	if(isset($args->active)){$setting->active = $args->active;}
	if(isset($args->croninterval)){$setting->croninterval = $args->croninterval;}
	if(isset($args->lastrun)){$setting->lastrun = $args->lastrun;}
	saveFileTo("institutionroot", "/", $CFG->cronsetting, $setting);
	return true;
}
function checkcronstatus(){
	if(has_internet() && isloggedin()){
		$setting = get_cronsetting();
		if($setting->active){
			$nextrun = strtotime("+{$setting->croninterval} minutes", $setting->lastrun);
			if($nextrun < time()){
				syncAllHomeworks();
				syncAllUsers();
				syncAlldevicelist();
				syncAlluserdata('all');
				$setting->lastrun = time();
				set_cronsetting($setting);
			}
		}
	}
}
function get_UserSetting() {
	global $CFG;
	$filedata = getFileForm("userroot", "/", $CFG->usersetting);
	if($filedata){
		$finaldata = json_decode($filedata);
	}
	if(empty($finaldata)){
		$finaldata = new stdClass();
		$finaldata->userlang = "EN";
	}
	return $finaldata;
}
function set_UserSetting($args) {
	global $CFG;
	$setting = get_UserSetting();
	foreach ($args as $key => $value) {
		$setting->$key = $value;
	}
	saveFileTo("userroot", "/", $CFG->usersetting, $setting);
	return true;
}

function syncAllevents() {
	global $CFG, $API;
	if(has_internet()){
		sync_eventUpdate();
		$reqdata = array();
		$response = $API->call("getCalendarEvents",$reqdata);
		if($response->code == 200) {
			saveFileTo("institutionroot", "/", $CFG->eventdata, $response->data);
		}
	}
}

function get_allevents() {
	global $CFG;
	syncAllevents();
	$filedata = getFileForm("institutionroot", "/", $CFG->eventdata);
	if($filedata){
		$alldata = json_decode($filedata);
	} else {
		$alldata = new stdClass();
		$alldata->events = array();
		$alldata->lastsynced = 0;
		$alldata->institutionId = 0;
	}
	return $alldata;
}
function get_calendarevents($args)
{
	global $USER;
	$eventdata = get_allevents();
	$filterdata = array();
	if(is_array($eventdata->events)){
		$allstatus = get_alleventstatus();

		$args['userids'] = array($USER->id);
		$args['timestart'] = strtotime($args['start']); 
		$args['timeend']	= strtotime($args['end']); 
		// print_r($args);
		// echo '-------';
		// print_r($eventdata->events);
		$filterdata = array_values(array_filter($eventdata->events, function ($event) use ($args) {
	    	return (in_array($event->teacherid, $args['userids']) && ($event->timestart > $args['timestart']) && ($event->timeend <= $args['timeend']));
		}));

		foreach ($filterdata as $key => $data) {
			$mystatus = array_values(array_filter($allstatus, function ($event) use ($data) {
		    	return ($data->id == $event->eventid);
			}));
			if(sizeof($mystatus) > 0){
				$laststatus = array_pop($mystatus);
				$data->status = $laststatus->status;
			}

			$filterdata[$key] = $data;
		}

	}
	return $filterdata;
}
function get_alleventstatus() {
	global $CFG;
	$filedata = getFileForm("institutionroot", "/", $CFG->eventstatus);
	if($filedata){
		$alldata = json_decode($filedata);
	}
	if(!is_array($alldata)){
		$alldata = array();
	}
	return $alldata;
}

function save_event_update_off($args) {
	global $API, $CFG;
	$allstatus = get_alleventstatus();
	$args->updatedtime = time();
	array_push($allstatus, $args);
	saveFileTo("institutionroot", "/", $CFG->eventstatus, $allstatus);	
	return true;
}

function sync_eventUpdate() {
	global $CFG, $API;
	$args = new stdClass();
	$args->allstatus = get_alleventstatus();
	$APIRES = $API->call("updateBulkEventStatus", $args);
	if($APIRES->code == 200 && $APIRES->data && $APIRES->data->event){
		saveFileTo("institutionroot", "/", $CFG->eventstatus, $APIRES->data->event);
	}
}
