<?php
/**
 * 
 */
class outputRenderer
{
	private $jqueryontop;
  private $internetstatus = 0;
  private $state=0;
  private $lang="EN";
  private $alllang=array("FR"=>"French", "EN"=>"English");

	function __construct()
	{
    global $CURRENTLANG;
    $this->jqueryontop=false;
    $this->checkInternatConnection();
    if(isset($_GET['changelang'])){
      $this->lang = $_GET['changelang'];
      $CURRENTLANG = $this->lang;
      $params = array("userlang" => $this->lang);
      set_UserSetting($params);
      $pageurl = get_current_pageurl();
      $allparams = get_allparameter();
      unset($allparams['changelang']);
      $pageurl = $pageurl.'?'. get_qsparameter($allparams);
      redirect($pageurl);
    }
    $this->getlanguageDropdown();
	}
  private function getlanguageDropdown() {
    global $CURRENTLANG;
    $usersetting = get_UserSetting();
    if(isset($usersetting->userlang) && array_key_exists($usersetting->userlang, $this->alllang)){
      $this->lang = $usersetting->userlang;
    }
    $userlang = $this->lang;
    $CURRENTLANG = $this->lang;
    $langdropdown = '';
    $langdropdown .= '<li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="langDropdown" href="#" data-toggle="dropdown">
              '.(isset($this->alllang[$userlang])?$this->alllang[$userlang]:$userlang).'
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">';
            foreach ($this->alllang as $key => $lang) {
              if($userlang == $key){continue;}
              $langdropdown .= '<a class="dropdown-item" href="'.$this->generatelangurl($key).'">'.(isset($alllang[$lang])?$alllang[$lang]:$lang).'</a>';
            }
    $langdropdown .= '</div>
          </li>';
    return $langdropdown;
  }
  private function generatelangurl($lang){
    $pageurl = get_current_pageurl();
    $allparams = get_allparameter();
    $allparams['changelang']=$lang; 
    $pageurl = $pageurl.'?'. get_qsparameter($allparams);
    return $pageurl;
  }
  private function getInternatConnectionStatus()
  {
    $msg = '<div class="alert alert-warning"><button type="button" userchoiceupdate data-choice = "stopinternetstatus" class="close" data-dismiss="alert">&times;</button>Serer not connected to internet.</div>';
    switch ($this->internetstatus){
      case 1:
        $msg = '<div class="alert alert-success"><button type="button"  userchoiceupdate data-choice = "stopinternetstatus" class="close" data-dismiss="alert">&times;</button>Server connected to internet.</div>';
      break;
      default:
        $msg = '<div class="alert alert-warning"><button type="button"  userchoiceupdate data-choice = "stopinternetstatus" class="close" data-dismiss="alert">&times;</button>Serer not connected to internet.</div>';
      break;
    }
    return $msg;
  }
  private function checkInternatConnection()
  {
    global $CFG;
    $status = 0;
    if ( @fopen($CFG->apiroot, "r") ) 
    {
      $status = 1;
    } 
    $CFG->internetstatus = $status;
    $this->internetstatus = $status;
    return $status;
  }
  public function loadjquery()
  {
    $this->jqueryontop=true;
  }
	public function header($value='')
	{
		global $CFG;
    $langdropdown = $this->getlanguageDropdown();
		$html='<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Fivestudents Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/vendors/feather/feather.css">
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/vendors/mdi/css/materialdesignicons.min.css?ver=1.0.0" type="text/css" media="all" />

  <link rel="stylesheet" type="text/css" href="'.$CFG->wwwroot.'/js/select.dataTables.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/css/vertical-layout-light/style.css">
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/calendar/calender_script/jquery-ui.css">
  <link rel="stylesheet" href="'.$CFG->wwwroot.'/calendar/calender_script/fullcalendar.min.css" />

  <link rel="stylesheet" href="'.$CFG->wwwroot.'/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="'.$CFG->wwwroot.'//images/logo-mini.png" />';
if($this->jqueryontop){
  $html.= $this->getjQuery();
}
$html .='
<style>
:root {
  --wwwroot: '.$CFG->wwwroot.';
}
</style>
';
$bodyclass = (isset($_SESSION['mainbodyclass']) && $_SESSION['mainbodyclass'])?'sidebar-icon-only':'';
$html .='</head>
<body class="'.$bodyclass.'">
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo mr-5" href="'.$CFG->wwwroot.'/"><img src="'.$CFG->wwwroot.'/images/Five-Students-Logo.png" class="mr-2" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="'.$CFG->wwwroot.'/"><img src="'.$CFG->wwwroot.'/images/logo-mini.png" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <button class="navbar-toggler navbar-toggler align-self-center" tooglesidebar data-choice = "mainbodyclass" type="button" data-toggle="minimize">
          <span class="icon-menu"></span>
        </button>
        <ul class="navbar-nav navbar-nav-right">
          '.$langdropdown.'
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
              <span class="userprofile">'.fullname().'</span>
              <img src="'.$CFG->wwwroot.'/images/user.png" alt="profile"/>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <!--<a class="dropdown-item">
                <i class="ti-settings text-primary"></i>
                Settings
              </a>-->
              <a href="'.$CFG->wwwroot.'/settings/cron/" class="dropdown-item">
                <i class="mdi mdi-cloud-sync text-primary"></i>
                '.get_string("cronsettins", "site").'
              </a>
              <a href="'.$CFG->wwwroot.'/login/logout.php" class="dropdown-item">
                <i class="ti-power-off text-primary"></i>
                '.get_string("logout", "site").'
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      <!--<div class="theme-setting-wrapper">
        <div id="settings-trigger"><i class="ti-settings"></i></div>
        <div id="theme-settings" class="settings-panel">
          <i class="settings-close ti-close"></i>
          <p class="settings-heading">SIDEBAR SKINS</p>
          <div class="sidebar-bg-options selected" id="sidebar-light-theme"><div class="img-ss rounded-circle bg-light border mr-3"></div>Light</div>
          <div class="sidebar-bg-options" id="sidebar-dark-theme"><div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark</div>
          <p class="settings-heading mt-2">HEADER SKINS</p>
          <div class="color-tiles mx-0 px-4">
            <div class="tiles success"></div>
            <div class="tiles warning"></div>
            <div class="tiles danger"></div>
            <div class="tiles info"></div>
            <div class="tiles dark"></div>
            <div class="tiles default"></div>
          </div>
        </div>
      </div>-->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/dashboard">
              <i class="icon-grid menu-icon"></i>
              <span class="menu-title">'.get_string('dashboard', 'site').'</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/users">
              <i class="icon-head menu-icon"></i>
              <span class="menu-title">'.get_string('users', 'site').'</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/calendar">
              <i class="mdi mdi-calendar-multiple menu-icon"></i>
              <span class="menu-title">'.get_string('calendar', 'site').'</span>
            </a>
          </li>';
          if(has_internet()){
            $html .= '<li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/groups">
              <i class="mdi mdi-vector-circle menu-icon"></i>
              <span class="menu-title">'.get_string('groups', 'site').'</span>
            </a>
          </li>';
          }
$html .='
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/homeworks">
              <i class="mdi mdi-drawing-box menu-icon"></i>
              <span class="menu-title">'.get_string('homeworks', 'site').'</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/reports">
              <i class="icon-bar-graph menu-icon"></i>
              <span class="menu-title">'.get_string('reports', 'form').'</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/gradedata">
              <i class="menu-icon mdi mdi-cloud-sync"></i>
              <span class="menu-title">'.get_string('gradedata', 'site').'</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="'.$CFG->wwwroot.'/devices-list/">
              <i class="menu-icon mdi mdi-cellphone"></i>
              <span class="menu-title">'.get_string("devices", "site").'</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" title="'.fullname().'" href="'.$CFG->wwwroot.'/login/logout.php" aria-expanded="false">
              <i class="ti-power-off menu-icon"></i>
              <span class="menu-title">'.get_string("logout", "site").'</span>
            </a>
          </li>          
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">';
    $html .= $this->notification();
    if(!isset($_SESSION['stopinternetstatus']) || !$_SESSION['stopinternetstatus']){
      $html .= $this->getInternatConnectionStatus();
    }
    $this->state = 1;
    return $html;
	}
  public function getjQuery()
  {
    global $CFG;
    $html ='
    <script type="text/javascript">
      var CFG = {
        wwwroot: "'.$CFG->wwwroot.'"
      }
    </script>
         <!-- plugins:js -->
      <script src="'.$CFG->wwwroot.'/vendors/js/vendor.bundle.base.js"></script>
      <!-- endinject -->
      <!-- Plugin js for this page -->
      <script src="'.$CFG->wwwroot.'/vendors/chart.js/Chart.min.js"></script>
      <script src="'.$CFG->wwwroot.'/vendors/datatables.net/jquery.dataTables.js"></script>
      <script src="'.$CFG->wwwroot.'/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
      <script src="'.$CFG->wwwroot.'/js/dataTables.select.min.js"></script>

      <!-- End plugin js for this page -->
      <!-- inject:js -->
      <script src="'.$CFG->wwwroot.'/js/off-canvas.js"></script>
      <script src="'.$CFG->wwwroot.'/js/hoverable-collapse.js"></script>
      <script src="'.$CFG->wwwroot.'/js/template.js"></script>
      <script src="'.$CFG->wwwroot.'/js/settings.js"></script>
      <script src="'.$CFG->wwwroot.'/js/todolist.js"></script>
      <!-- endinject -->
      <!-- Custom js for this page-->
      <script src="'.$CFG->wwwroot.'/js/Chart.roundedBarCharts.js"></script>
      <!-- End custom js for this page-->
      <script src="'.$CFG->wwwroot.'/js/blazy.min.js" type="text/javascript"></script>
      <script src="'.$CFG->wwwroot.'/calendar/calender_script/jquery-ui.js"></script>
      <script src="'.$CFG->wwwroot.'/calendar/calender_script/moment.min.js"></script>
      <script src="'.$CFG->wwwroot.'/calendar/calender_script/fullcalendar.min.js"></script>

      <script src="'.$CFG->wwwroot.'/js/app.js" type="text/javascript"></script>
    ';
    return $html;
  }
	public function footer()
	{
		global $CFG;
		$html = '</div>
		        <!-- content-wrapper ends -->
		        <!-- partial:partials/_footer.html -->
		        <footer class="footer">
		          <div class="d-sm-flex justify-content-center justify-content-sm-between">
		            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright &copy; '.date("Y").'. <a href="https://plus.fivestudents.com/" target="_blank">fivestudents.com</a></span>
		          </div>
		        </footer>
		        <!-- partial -->
		      </div>
		      <!-- main-panel ends -->
		    </div>
		    <!-- page-body-wrapper ends -->
		  </div>
		  <!-- container-scroller -->';
    if(!$this->jqueryontop){
      $html.= $this->getjQuery();
    }


    $html.='		</body>

		</html>';
    $this->state = 1;
		return $html;
	}
  public function redirect_message($encodedurl) {
    global $CFG;
    $output = "";
    if($this->state == 0){
      $output .= $this->header();
    }
    $output .= $this->notification();
    $output .= '<div class="continuebutton text-center">(<a href="'. $encodedurl .'">Continue</a>)</div>';
    // if ($debugdisableredirect) {
    //     $output .= '<p><strong>Error output, so disabling automatic redirect.</strong></p>';
    // }
    if($this->state == 1){
      $output .= $this->footer();
    }
    return $output;
  }
  public function notification()
  {
    $alltype = array("info", "success", "warning", "error");
    $html = '';
    $message = isset($_SESSION['redirectmessage'])?$_SESSION['redirectmessage']:'';
    $messagetype = strtolower(isset($_SESSION['redirecttype'])?$_SESSION['redirecttype']:'');
    if($message){
      $html ='<div class="alert alert-'.(in_array($messagetype, $alltype)?$messagetype:'info').'">'.$message.'</div>';
      unset($_SESSION['redirectmessage']);
      unset($_SESSION['redirecttype']);
    }
    return $html;
  }
}