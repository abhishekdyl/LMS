<?php
/**
 * 
 */
class APIManager
{
  private $serverurl = ""; 
  function __construct()
  {
    global $CFG;
    $this->serverurl = $CFG->apiroot."/app_rest_api/offline/index.php";
  }
  public function call($wsfunction, $args=array(), $accessrole='tutor'){
    global $CFG;
    if(is_array($args)){
        $args = (object)$args;
    }
    if(!isset($args->devicetoken)){$args->devicetoken="tutordevice";}
    if(!isset($args->devicename)){$args->devicename="tutordevice";}
    if(!isset($args->accessrole)){$args->accessrole=$accessrole;}
    $wstoken = get_logintoken();
    $finalcall = new stdClass();
    $finalcall->wsfunction = $wsfunction;
    $finalcall->wstoken = $wstoken;
    $finalcall->wsargs = $args;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $this->serverurl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>json_encode($finalcall),
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
    ));
    if($response = curl_exec($curl)){
        if($response= json_decode($response)){
            if($response && $response->code==100){
                session_destroy();
                redirect("{$CFG->wwwroot}/login/");;
            }
            return $response;
        } else {
            return $response;
        }
    }
    return null;
  }
}