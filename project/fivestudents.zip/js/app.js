(function($) {
  getAPIRequest = function(fname, args){
    var settings = {
      "url": CFG.wwwroot+"/app_rest_api/offline/index.php",
      "method": "POST",
      "timeout": 0,
      "headers": {
        "Content-Type": "application/json",
      },
        "data": JSON.stringify({
          "wsfunction": fname,
          "wsargs": args
        }),
    };
    return settings;
  };
})(jQuery);
(function($) {
  'use strict';
  $(function() {
    $('[userchoiceupdate]').click(function() {
      var args = getAPIRequest("userChoiceUpdate", {
        "element": $(this).data("choice")
      });
      $.ajax(args).done(function (response) {});
    });
    $('[tooglesidebar]').click(function() {
      var args = getAPIRequest("userChoiceUpdate", {
        "element": $(this).data("choice"),
        "value": $("body").hasClass("sidebar-icon-only")
      });
      $.ajax(args).done(function (response) {});
    });
  });
})(jQuery);