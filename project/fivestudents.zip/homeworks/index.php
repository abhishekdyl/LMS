<?php
  require_once("../config.php");
  require_login();
  $syncnow = optional_param("syncnow", 0);
  if($syncnow){
    syncAllHomeworks();
    redirect("{$CFG->wwwroot}/homeworks");
  }
  $OUTPUT->loadjquery();
  $homeworkdata = get_allhomeworks();
  $lastsynced = "Never";
  if(is_object($homeworkdata) && !empty($homeworkdata->lastsynced)){
    $lastsynced = timestamp_to_date($homeworkdata->lastsynced);
  }
  echo $OUTPUT->header();
  $html = '';
  // $html .= '<pre>'.print_r($homeworkdata, true).'</pre>';
  $html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <p class="card-title mb-0">Homeworks <span class="badge">'.get_string("lastsynced",'site').': '.$lastsynced.'</span></p>
                  <div class="text-right">
                  '.(has_internet()?'<a class="btn btn-primary" href="'.$CFG->wwwroot.'/homeworks?syncnow=1">'.get_string("syncnow",'site').'</a>':'').'
                  </div>
                  <br/>
                  <div class="table-responsive">
                    <table id="userlist" class="table table-borderless">
                      <thead>
                        <tr>
                          <th class="pl-0  pb-2 border-bottom">Due date</th>
                          <th class="border-bottom pb-2">Publication date</th>
                          <th class="border-bottom pb-2">Name</th>
                          <th class="border-bottom pb-2">Level</th>
                          <th class="border-bottom pb-2">Group</th>
                          <th class="border-bottom pb-2">Semester/Unit</th>
                          <th class="border-bottom pb-2">Lesson/Assessment</th>
                          <th class="border-bottom pb-2">Task</th>
                          <th class="border-bottom pb-2">Total Question</th>
                          <th class="border-bottom pb-2">Status</th>
                          <th class="border-bottom pb-2">Creation date</th>
                          <th class="border-bottom pb-2"></th>
                        </tr>
                      </thead>
                      <tbody>';
  if(is_object($homeworkdata) && is_array($homeworkdata->homeworks)){
    foreach ($homeworkdata->homeworks as $key => $homework) {
      $html .='<tr>
        <td>'.timestamp_to_date($homework->duedate).'</td>
        <td>'.timestamp_to_date($homework->homeworkdate).'</td>
        <td>'.$homework->name.'</td>
        <td>'.$homework->grade.'</td>
        <td>'.$homework->group_name.'</td>
        <td>'.$homework->topicname.'</td>
        <td>'.$homework->subtopicname.'</td>
        <td>'.$homework->quizname.'</td>
        <td>'.$homework->totalquestion.'</td>
        <td>'.($homework->status?'Published':'Planned').'</td>
        <td>'.timestamp_to_date($homework->createddate).'</td>
        <td><a href="'.$CFG->wwwroot.'/homeworks/report/?homeworkid='.$homework->id.'"><i class="mdi mdi-pulse"></i> Report</a></td>
      </tr>';
    }
  }
  $html .='
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  $html .='<script>
              $("#userlist").DataTable();
            </script>';
  echo $html;
  echo $OUTPUT->footer();
