<?php
  require_once("../config.php");
  require_login();
  $syncnow = optional_param("syncnow", 0);
  if($syncnow){
    syncAllGroups();
    redirect("{$CFG->wwwroot}/groups");
  }
  $OUTPUT->loadjquery();
  $groupdata = get_allgroups();
  $lastsynced = "Never";
  if(is_object($groupdata) && !empty($groupdata->lastsynced)){
    $lastsynced = timestamp_to_date($groupdata->lastsynced);
  }
  echo $OUTPUT->header();
  $html = '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <p class="card-title mb-0">Groups <span class="badge">'.get_string("lastsynced",'site').': '.$lastsynced.'</span></p>
                  <div class="text-right">
                  '.(has_internet()?'<a class="btn btn-primary" href="'.$CFG->wwwroot.'/groups?syncnow=1">'.get_string("syncnow",'site').'</a>':'').'
                  </div>
                  <br/>
                  <div class="table-responsive">
                    <table id="userlist" class="table table-borderless">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Level</th>
                          <th>Subject</th>
                          <th>Teacher</th>
                          <th>Number of students</th>
                          <th>To be Approved</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>';
  if(is_object($groupdata) && is_array($groupdata->groups)){
    foreach ($groupdata->groups as $key => $group) {
      $html .=  '<tr>
                  <td class="py-1">'.$group->name.'</td>
                  <td class="py-1">'.$group->grade.'</td>
                  <td class="py-1">'.$group->coursename.'</td>
                  <td class="">'.$group->teachers.'</td>
                  <td class="">'.$group->totalusers.'</td>
                  <td class="">'.$group->pendingapproval.'</td>
                  <td class="">
                    <a href="'.$CFG->wwwroot.'/groups/details?id='.$group->id.'"> Details </a> &nbsp; &nbsp;
                  </td>
                </tr>';
    }
  }
  $html .='
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  $html .='<script>
              $("#userlist").DataTable();
            </script>';
  echo $html;
  echo $OUTPUT->footer();
