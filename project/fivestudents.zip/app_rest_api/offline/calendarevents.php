<?php
include('../../config.php');
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');
header("HTTP/1.0 200 Successfull operation");
global $CFG, $USER, $SESSION, $API;
$events = array();
// if(is_user_logged_in()){
    // $MOODLE = new MoodleManager();
$args =$_GET;
$filtereddata = get_calendarevents($args);

if(is_array($filtereddata)){
    foreach ($filtereddata as $key => $event) {
        $eventstatus = "none";
        $canstart = false;
        $cancancel = false;
        $cancomplete = false;
        $canedit = false;
        $canadd = false;
        // if(current_user_can('plus_editevents')){
        //     $canadd = true;
        //     if($event->status == 0){
        //         $canedit = true;
        //     }
        // }
        if($event->status == 0){
            $canstart = true;
        }
        if($event->status != 2 && $event->status != 3){
            $cancancel = true;
        }
        if($event->status == 1){
            $cancomplete = true;
        }
        switch ($event->status) {
            case 0:
                $eventstatus = "none";
                break;
            case 1:
                $eventstatus = "started";
                break;
            case 2:
                $eventstatus = "cancelled";
                break;
            case 3:
                $eventstatus = "completed";
                break;
            case 4:
                $eventstatus = "past";
                break;
            case 5:
                $eventstatus = "claim";
                break;
            case 6:
                $eventstatus = "inprogress";
                break;
            default:
                // code...
                break;
        }
        $event->canstart = $canstart;
        $event->eventstatus = ucfirst($eventstatus);
        $event->cancancel = $cancancel;
        $event->cancomplete = $cancomplete;
        $event->canadd = $canadd;
        $event->canedit = $canedit;
        $eventname = $event->name;
        if(!empty($event->coursename)){
            $eventname = $event->coursename;
        }
        if(!empty($event->groupname)){
            $eventname .= "({$event->groupname})";
        }
        array_push($events, array(
            "start"=>date("Y-m-d\TH:i:s", $event->timestart),
            "end"=>date("Y-m-d\TH:i:s", $event->timeend),
            "duration"=>$event->duration,
            "title"=>$eventname,
            "description"=>$event->description,
            "fulldata"=>$event,
            "className"=>array('status-'.$eventstatus),
        ));
    }
}
    // echo '<pre>---------------';
    // print_r($events);
    // echo '</pre>';

// }
// $demodata = new stdClass();
// $demodata->start = date("Y-m-d", time());
// $demodata->title = '('.date("h:i", time()).'-'.date("h:i", time()).')';
// $demodata = new stdClass();
// $demodata->start = date("Y-m-d", time());
// $demodata->title = '('.date("h:i", time()).'-'.date("h:i", time()).')';
// array_push($events, $demodata);
echo json_encode($events);
