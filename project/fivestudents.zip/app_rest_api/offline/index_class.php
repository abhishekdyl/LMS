<?php
class LOCALAPIManager {
    private $token = ""; 
    private $currentYear = null; 
    private $currentschoolyear = 0;
    private $allinstitution = array();
    private $institution = null;
    private $institutionid = 0;
    public $status = 0; 
    public $message = "Error";
    public $data = null;
    public $code = 404;
    public $currenttime = 0;
    public $istutor = false;
    public $error = array(
        "code"=> 404,
        "title"=> "Server Error.", 
        "message"=> "server under maintenance"
    );
    function __construct() { 
        $this->currenttime = time();
        $this->code = 400;
        $this->setLocaldata();
        $this->error = array(
            "code"=> 400,
            "title"=> "Server Error..",
            "message"=> "Missing functionality"
        );
    }
    private function setLocaldata() {
        global $DB, $CFG;
        $data = getFile($CFG->dataroot. "/login.tmp");
        try {
            $finaldata = json_decode($data);
            $this->currentYear = $finaldata->currentYear;
            $this->currentschoolyear = $finaldata->currentschoolyear;
            $this->allinstitution = $finaldata->allinstitution;
            $this->institution = $finaldata->institution;
            $this->institutionid = $finaldata->institutionid;
            $this->istutor = $finaldata->istutor;
            $this->token = $finaldata->token;
        } catch (Exception $e) {
            
        }
    }
    private function sendResponse($data) {
        $this->status = 1;
        $this->message = "Success";
        $this->data = $data;
        $this->code = 200;
        $this->error = null;
    }
    public function sendError($title, $message, $code=400, $data=null) {
        $this->status = 0;
        $this->message = "Error";
        $this->data = null;
        $this->code = $code;
        $this->error = array(
            "code"=> $code,
            "title"=> $title,
            "message"=> $message,
            "data"=> $data
        );
    }
    public function getUserCredentials($args) {
        global $DB, $INSTITUTION;
        if($institutionid = $args['institutionid']){
            $INSTITUTION = (object)array("institutionid"=>$institutionid);
            $allusersdata = get_allusers();
            $response = new stdClass();
            $response->credentials = $allusersdata->credentials;
            $response->institutionId = $allusersdata->institutionId;
            $response->lastsynced = $allusersdata->lastsynced;
            $this->sendResponse($response);
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }
    public function getOfflineHomeWork($args) {
        global $DB, $INSTITUTION;
        if($institutionid = $args['institutionid']){
            $INSTITUTION = (object)array("institutionid"=>$institutionid);
            $homeworkdata = get_allhomeworks();
            $response = new stdClass();
            $response->homeworks = $homeworkdata->homeworks;
            $response->institutionId = $homeworkdata->institutionId;
            $response->lastsynced = $homeworkdata->lastsynced;
            $this->sendResponse($response);
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }
    public function getOfflineHomeWorkBlockStatus($args) {
        global $DB, $INSTITUTION;
        if($institutionid = $args['institutionid'] && $homeworkid = $args['homeworkid']){
			$this->INSTITUTION = $INSTITUTION;

            $homework = get_homeworkreport($homeworkid);
            if($homework){
                $homeqordquestionstatus = gethomeqordquestionstatus($homeworkid);
                $response = new stdClass();
                $response->blockings = $homeqordquestionstatus;
                $this->sendResponse($response);
            } else {
                $this->sendError("Invalid Request", "Homeqork not found");
            }
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }

    public function getHomeworks() {
        global $DB;
        if($this->istutor){
            $homeworkdata = get_allhomeworks();
            $response = new stdClass();
            $response->homeworks = $homeworkdata->homeworks;
            $response->institutionId = $homeworkdata->institutionId;
            $response->lastsynced = $homeworkdata->lastsynced;
            $this->sendResponse($response);
        } else {
            $this->sendError("Unauthorized Access", "You don't have access.");
        }
    }
    public function dataSyncStatus($args) {
        global $DB, $USER;
        $lastsynced = $args['lastsynced']?$args['lastsynced']:0;
        $synceddata = get_awaitingsynceddata("synced");
        $awaiting = array_filter($synceddata->data, function ($file) use ($synced) {
            return $file->processtime > $lastsynced;
        });
        $allremainingData = array();
        $this->sendResponse(array("data"=>$allremainingData,"synceddata"=>$synceddata->data, "updateddate"=>time()));
    }
    public function getUpdatedfiledata($args) {
        global $DB, $USER, $CFG;
        $reqid = $args['reqid'];
        try { 
            if($filedata = get_syncedfiledata($reqid)){
                $responsedata = array(
                    "filedata"=>base64_encode($filedata), 
                );
                $this->sendResponse($responsedata);
            } else {
                $this->sendError("Failed", "Please Try again later");
            }
        } catch (Exception $e) {
            $this->sendError("Failed", "Please Try again later");
        }
    }
    public function userChoiceUpdate($args) {
        if(!empty($args['element'])){
            $element = $args['element'];
            if(!isset($args['value'])){
               $_SESSION[$element]=true;
            } else {
               $_SESSION[$element]=$args['value'];
           }
            $this->sendResponse(array("success"=>true));
        } else {
            $this->sendError("Failed", "Please Try again later");
        }
    }
    public function getServerStatus($args) {
        $this->sendResponse(array("success"=>true));
    }

    public function updateEventStatus($args) {
        global  $DB, $USER, $CFG, $API;
        $args = (object)$args;
        if(save_event_update_off($args)){
            $this->sendResponse(array("status"=>1));
        } else {
            $this->sendError("Error", "Failed to update status");
        }
    }

}