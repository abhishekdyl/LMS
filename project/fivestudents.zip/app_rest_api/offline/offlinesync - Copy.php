<?php
require_once("../../config.php");
require_once("index_class.php");
define('NO_DEBUG_DISPLAY', true);
define('WS_SERVER', true);
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
header("HTTP/1.0 200 Successfull operation");

$target_dir = "{$CFG->dataroot}/offlineuploads/";
// $target_dir = "/var/www/html/app_rest_api/offline/offlineuploads/";
$filename = time().'_'.rand().'_'.basename($_FILES["localfile"]["name"]);
$target_file = $target_dir.$filename;
// echo $target_file;
$filesize = $_FILES["localfile"]['size'];
$filepath = $target_file;
$uploadOk = 1;
if($_FILES["localfile"]){
    if (move_uploaded_file($_FILES["localfile"]["tmp_name"], $target_file)) {
        $localsyncfile = new stdClass();
        $localsyncfile->filename = $filename;
        $localsyncfile->filesize = $filesize;
        $localsyncfile->filepath = $filepath;
        $localsyncfile->uploadedtime = time();
        if($DB->insert_record("localsyncfile", $localsyncfile)){
            echo json_encode(array("status"=>1, "message"=>"Uploaded Successfull"));
        } else {
            echo json_encode(array("status"=>0, "message"=>"Failed to save data"));
        }
    } else {
        echo json_encode(array("status"=>0, "message"=>"Failed to upload data"));
    }
} else {
    echo json_encode(array("status"=>0, "message"=>"Failed to upload data111111111111111"));
}
