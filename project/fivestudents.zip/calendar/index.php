<?php
require_once("../config.php");
global $DB, $PAGE, $CFG, $USER, $OUTPUT;
require_login();

$OUTPUT->loadjquery();
$canadd =false;
$html ='<input type="hidden" id="institutionid" value="0"/>';
$html .='<input type="hidden" id="teacherid" value="0"/>';
$html .="
<div id= 'calendar'></div>
<script>
    $(document).ready(function() {

        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title', 
                right: 'month,agendaWeek,agendaDay".($canadd?",addEventButton":"")."'
            },
            events: {
                url: '".$CFG->wwwroot."/app_rest_api/offline/calendarevents.php',
                type: 'GET',
                data: {
                    institutionid: $('#institutionid').val(),
                    teacherid: $('#teacherid').val()
                }
            },
            defaultDate: moment().format('YYYY-MM-DD'),
            // defaultView: 'agendaWeek',
            editable: false,
            eventLimit: true, 
            eventClick: function(calEvent, jsEvent, view) {
                var prevent = calEvent['fulldata'];
                console.log('prevent- ', prevent);
                var sttime = calEvent.start._i;
                var edtime = calEvent.end._i;
                var dialog = \$('<div class= row event_list >').append(
                    \$('<h5>').addClass('col-sm-3').text(' School : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'text').prop('disabled', true).attr('value',prevent.institution),
                    \$('<h5>').addClass('col-sm-3').text(' User : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'text').prop('disabled', true).attr('value',prevent.teacher),
                    \$('<h5>').addClass('col-sm-3').text(' Group : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'text').prop('disabled', true).attr('value',prevent.groupname),
                    \$('<h5>').addClass('col-sm-3').text(' Subject : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'text').prop('disabled', true).attr('value',prevent.coursename),
                    \$('<h5>').addClass('col-sm-3').text(' Starttime : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'datetime-local').prop('disabled', true).attr('value',sttime),
                    \$('<h5>').addClass('col-sm-3').text(' Endtime : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'datetime-local').prop('disabled', true).attr('value',edtime),
                    \$('<h5>').addClass('col-sm-3').text(' Status : '),
                    \$('<input>').addClass('col-sm-9').attr('type', 'text').prop('disabled', true).attr('value',prevent.eventstatus),
                );
                var dialogbuttons = {};
                    if(prevent.canstart){
                        dialogbuttons.Start=function() {
                            var reqargs = {
                                'eventid': prevent.id,
                                'status': 1,
                                'message':''
                            };
                            var that = this;
                            \$.ajax({
                                'url': '".$CFG->wwwroot."/app_rest_api/offline/index.php',
                                'method': 'POST',
                                'timeout': 0,
                                'headers': {
                                'Content-Type': 'application/json',
                                },
                                'data': JSON.stringify({
                                'wsfunction': 'updateEventStatus',
                                'wsargs': reqargs
                                }),
                            }).done(function (response) {
                                $('#calendar').fullCalendar('refetchEvents');
                                $(that).dialog('close');
                            });
                        };
                    }
                    if(prevent.cancomplete){
                        dialogbuttons.Complete=function() {
                            var reqargs = {
                                'eventid': prevent.id,
                                'status': 3,
                                'message':''
                            };
                            var that = this;
                            \$.ajax({
                                'url': '".$CFG->wwwroot."/app_rest_api/offline/index.php',
                                'method': 'POST',
                                'timeout': 0,
                                'headers': {
                                'Content-Type': 'application/json',
                                },
                                'data': JSON.stringify({
                                'wsfunction': 'updateEventStatus',
                                'wsargs': reqargs
                                }),
                            }).done(function (response) {
                                $(that).dialog('close');
                                $('#calendar').fullCalendar('refetchEvents');
                            });
                        };
                    }
                    if(prevent.timestart < ".time()." && prevent.status == '4'){
                        
                        dialogbuttons.Claim=function() {
                            console.log('prevent---------- ', prevent);
                            $(this).dialog('close');

                            var label = $('<label>').text('Reason to claim the event:');
                            var input = $('<textarea>').attr('cols', '10').attr('rows', '10').attr('id', 'confirm_claim');
                            var dialog = $('<div>').addClass('dialogbody').append(
                                label,
                                input
                            ).dialog({
                                modal: true,
                                width: 400,
                                buttons: {
                                    'Confirm Claim': function() {
                                        var confirm_claim = $('#confirm_claim').val();
                                        // console.log('confirm_claim-------- ', confirm_claim);
                                        var reqargs = {
                                            'eventid': prevent.id,
                                            'status': 5,
                                            'message':confirm_claim
                                        };
                                        // console.log('reqargs---- ', reqargs);
                                        var that = this;
                                        if(confirm_claim == ''){
                                            alert('Please add Reason to Claim this event');
                                            return;
                                        }
                                        \$.ajax({
                                            'url': '".$CFG->wwwroot."/app_rest_api/offline/index.php',
                                            'method': 'POST',
                                            'timeout': 0,
                                            'headers': {
                                            'Content-Type': 'application/json',
                                            },
                                            'data': JSON.stringify({
                                            'wsfunction': 'updateEventStatus',
                                            'wsargs': reqargs
                                            }),
                                        }).done(function (response) {
                                            $(that).dialog('close');
                                            $('#calendar').fullCalendar('refetchEvents');
                                        });
                                    },
                                    'Close': function() {
                                        $(this).dialog('close');
                                    }
                                }
                            });

                        }
                    
                    }
 
                    if(prevent.cancancel){
                        dialogbuttons.Cancel=function() {
                            $(this).dialog('close');
                            var label = $('<label>').text('Reason for Cancel the event:');
                            var input = $('<textarea>').attr('cols', '10').attr('rows', '10').attr('id', 'cancelmessage');
                            var dialog = $('<div>').addClass('dialogbody').append(
                                label,
                                input
                            ).dialog({
                                modal: true,
                                width: 400,
                                buttons: {
                                    'Confirm Cancel': function() {
                                        var cancelmessage = $('#cancelmessage').val();
                                        var reqargs = {
                                            'eventid': prevent.id,
                                            'status': 2,
                                            'message':cancelmessage
                                        };
                                        var that = this;
                                        if(cancelmessage == ''){
                                            alert('Please add Reason to Cancel this event');
                                            return;
                                        }
                                        \$.ajax({
                                            'url': '".$CFG->wwwroot."/app_rest_api/offline/index.php',
                                            'method': 'POST',
                                            'timeout': 0,
                                            'headers': {
                                            'Content-Type': 'application/json',
                                            },
                                            'data': JSON.stringify({
                                            'wsfunction': 'updateEventStatus',
                                            'wsargs': reqargs
                                            }),
                                        }).done(function (response) {
                                            $(that).dialog('close');
                                            $('#calendar').fullCalendar('refetchEvents');
                                        });
                                    },
                                    'Close': function() {
                                        $(this).dialog('close');
                                    }
                                }
                            });
                        };
                    }

                    dialogbuttons.Close=function() {
                        $(this).dialog('close');
                    }

                dialogbuttons.Close=function() {
                    $(this).dialog('close');
                }
                
                dialog.dialog({
                    modal: true,
                    width: 800,
                    maxWidth: 900,
                    buttons: dialogbuttons
                });
                console.log(`eventClick calEvent: `, calEvent)
                console.log(`eventClick jsEvent: `, jsEvent)
                console.log(`eventClick view: `, view)
            },
            dayClick: function(date, jsEvent, view) {
                console.log(`dayClick date: `, date)
                console.log(`dayClick jsEvent: `, jsEvent)
                console.log(`dayClick view: `, view)
                
            }
        });    
    });
</script>";

echo $OUTPUT->header();
echo $html;
echo $OUTPUT->footer();