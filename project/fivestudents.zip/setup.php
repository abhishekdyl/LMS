<?php
function checkdirpath($path)
{
    if(!is_dir($path)) { mkdir($path, 0777, true); }
}
$CFG->dirroot = __DIR__;
if(empty($CFG->dataroot)){
    $CFG->dataroot = "{$CFG->dirroot}/userdata";
}
checkdirpath($CFG->dataroot);
if ($CFG->dataroot === false) {
    if (isset($_SERVER['REMOTE_ADDR'])) {
        header($_SERVER['SERVER_PROTOCOL'] . ' 503 Service Unavailable');
    }
    echo('Fatal error: $CFG->dataroot is not configured properly, directory does not exist or is not accessible! Exiting.'."\n");
    exit(1);
} else if (!is_writable($CFG->dataroot)) {
    if (isset($_SERVER['REMOTE_ADDR'])) {
        header($_SERVER['SERVER_PROTOCOL'] . ' 503 Service Unavailable');
    }
    echo('Fatal error: $CFG->dataroot is not writable, admin has to fix directory permissions! Exiting.'."\n");
    exit(1);
}
$CFG->syncdataroot = "{$CFG->dataroot}/".md5("syncdata");
checkdirpath($CFG->syncdataroot);
$CFG->localdataroot = "{$CFG->dataroot}/".md5("localdata");
checkdirpath($CFG->localdataroot);
$CFG->localorigdataroot = "{$CFG->localdataroot}/".md5("orig");
checkdirpath($CFG->localorigdataroot);
$CFG->apilogdata = md5("apilogdata.tmp");
$CFG->homeworkdata = md5("homeworkdata.tmp");
$CFG->devicekeys = md5("devicekeys");
$CFG->userdata = md5("userdata.tmp");
$CFG->cronsetting = md5("cronsetting.tmp");
$CFG->usersetting = md5("usersetting.tmp");
$CFG->eventdata = md5("eventdata.tmp");
$CFG->eventstatus = md5("eventstatus.tmp");
// wwwroot is mandatory
if (!isset($CFG->wwwroot)) {
    if (isset($_SERVER['REMOTE_ADDR'])) {
        header($_SERVER['SERVER_PROTOCOL'] . ' 503 Service Unavailable');
    }
    echo('Fatal error: $CFG->wwwroot is not configured! Exiting.'."\n");
    exit(1);
}
$CFG->libdir = $CFG->dirroot .'/lib';
$CFG->devicelist = md5("devicelist");
/**
 * Database connection. Used for all access to the database.
 * @global database $DB
 * @name $DB
 */
global $DB;

/**
 *  wrapper round PHP's $_SESSION.
 *
 * @global object $SESSION
 * @name $SESSION
 */
global $SESSION;

/**
 * Holds the user table record for the current user. Will be the 'guest'
 * user record for people who are not logged in.
 *
 * $USER is stored in the session.
 *
 * Items found in the user record:
 *  - $USER->email - The user's email address.
 *  - $USER->id - The unique integer identified of this user in the 'user' table.
 *  - $USER->email - The user's email address.
 *  - $USER->firstname - The user's first name.
 *  - $USER->lastname - The user's last name.
 *  - $USER->username - The user's login username.
 *  - $USER->secret - The user's ?.
 *  - $USER->lang - The user's language choice.
 *
 * @global object $USER
 * @name $USER
 */
global $USER;

/**
 * A central store of information about the current page we are
 * generating in response to the user's request.
 *
 * @global page $PAGE
 * @name $PAGE
 */
global $INSTITUTION;

/**
 * A central store of information about the current page we are
 * generating in response to the user's request.
 *
 * @global page $PAGE
 * @name $PAGE
 */
global $PAGE;

/**
 * $OUTPUT is an instance of core_renderer or one of its subclasses. Use
 * it to generate HTML for output.
 *
 * $OUTPUT is initialised the first time it is used. See {@link bootstrap_renderer}
 * for the magic that does that. After $OUTPUT has been initialised, any attempt
 * to change something that affects the current theme ($PAGE->course, logged in use,
 * httpsrequried ... will result in an exception.)
 *
 * Please note the $OUTPUT is replacing the old global $THEME object.
 *
 * @global object $OUTPUT
 * @name $OUTPUT
 */
global $OUTPUT;
global $API;
global $CURRENTLANG;
$CURRENTLANG = "EN";
session_start();
$errormessage="";
require_once("lang.php");
require_once("lib.php");
require_once("classes/output.php");
require_once("classes/APIManager.php");
base_init();
