<?php
  require_once("../config.php");
  $syncnow = optional_param("syncnow", "");
  if($syncnow){
    syncAlluserdata($syncnow);
    redirect("{$CFG->wwwroot}/dashboard");
  }

  $formdata = new stdClass();
  $formdata->categoryid = optional_param("categoryid", 0);
  $formdata->groupid = optional_param("groupid", 0);
  $formdata->homeworkid = optional_param("homeworkid", 0);
  $formdata->filtertype = optional_param("filtertype", 1);
  $formdata->fromdate = optional_param("fromdate", date("Y-m-d"));
  $formdata->todate = optional_param("todate", date("Y-m-d"));
  $formdata->attempt = optional_param("attempt", 1);
  require_login();
  $OUTPUT->loadjquery();

  $catcourses = '<option value="0">'.get_string("all", "site").'</option>';
  $groups = '<option value="0">'.get_string("all", "site").'</option>';
  $selectedgrade = null;
  $selectedgroup = null;
  $allgrades = array();
  $allgroup = array();

/*Dummy data*/
// getDashboardData
  $dashboarddata = getDashboardData($formdata);
  // echo "<pre>";
  // print_r($dashboarddata->dashdata);
  // echo "</pre>";
  $dashdata = $dashboarddata->dashdata;
  // echo "<pre>";
  // print_r($dashdata->homeworkdata);
// $dashdata = new stdClass();
// $dashdata->grades = array();
// $homeworkdata = array("notstarted"=>array("count"=>0, "total"=>0, "percent"=>0), "notpassed"=>array("count"=>0, "total"=>0, "percent"=>0), "notcompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "completed"=>array("count"=>0, "total"=>0, "percent"=>0),"latecompleted"=>array("count"=>0, "total"=>0, "percent"=>0), "passed"=>array("count"=>0, "total"=>0, "percent"=>0), "totalquizcompleted"=>0);
// $dashdata->homeworkkpi = json_decode(json_encode($homeworkdata));
  // print_r($dashdata);
  // die;
  if(isset($dashdata->grades) && sizeof($dashdata->grades)>0){
    $allgrades = $dashdata->grades;
    foreach ($dashdata->grades as $key => $grade) {
      // if($key == 0 ) {$selectedgrade = $grade;}
        $sel = '';
        if($grade->categoryid == $formdata->categoryid){
          $sel = "selected";
          $selectedgrade = $grade;
        }
        $catcourses .= '<option '.$sel.' value="'.$grade->categoryid.'">'.$grade->name.'</option>';
    }
  }
  if($selectedgrade && is_array($selectedgrade->allgroup) && !empty($selectedgrade->allgroup)){
      $sel = '';
      $allgroup = $selectedgrade->allgroup;
      foreach ($selectedgrade->allgroup as $key => $group) {
        $sel = "";
        if($group->groupid == $formdata->groupid){
          $sel = "selected";
          $selectedgroup = $group;
        }
        $groups .= '<option '.$sel.' value="'.$group->groupid.'">'.$group->name.'</option>';
      }
  }
  $homeworks = '<option value="0">'.get_string("all", "site").'</option>';
  if($selectedgroup && is_array($selectedgroup->homeworks) && !empty($selectedgroup->homeworks)){
      $sel = '';
      foreach ($selectedgroup->homeworks as $key => $homework) {
        $sel = "";
        if($homework->id == $formdata->homeworkid){
          $sel = "selected";
        }
        $homeworks .= '<option '.$sel.' value="'.$homework->id.'">'.$homework->name.'</option>';
      }
  }
  $reportpageurl = "{$CFG->wwwroot}/dashboard/report";
  $formdata->status = 0;
  $report_incompleted = getpageurl($reportpageurl, $formdata);
  $formdata->status = 1;
  $report_unstarted = getpageurl($reportpageurl, $formdata);
  $formdata->status = 2;
  $report_completed = getpageurl($reportpageurl, $formdata);
  $formdata->status = 5;
  $report_latecompleted = getpageurl($reportpageurl, $formdata);

  $formdata->status = 3;
  
  $report_passed = getpageurl($reportpageurl, $formdata);
  $formdata->status = 4;
  $report_failed = getpageurl($reportpageurl, $formdata);

  $report_incompleted = "javascript:void(0);";
  $report_unstarted = "javascript:void(0);";
  $report_completed = "javascript:void(0);";
  $report_latecompleted = "javascript:void(0);";
  $report_passed = "javascript:void(0);";
  $report_failed = "javascript:void(0);";
$kpihtml='';
if(!has_internet()){
  $kpihtml .='
    <style>
      #dashboardfilter {
        opacity: 0;
        visibility: hidden;
      }
    </style>
  ';

}


      $kpihtml .= '
            <div class="row homeworkstatus">
              <div class="col-md-6 grid-margin stretch-card">
                <div class="card tale-bg filterform">
                  <div class="card-people mt-auto">
                    <!--<img src="https://plus.fivestudents.com/wp-content/plugins/el-dashboard/public/images/dashboard/people.svg" alt="people">-->
                    <form id="dashboardfilter"  class="forms-sample blueform" autocomplete="off">
                      <div class="form-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">'.get_string("level", "form").'</span>
                          </div>
                          <select name="categoryid" class="form-control" id="categoryid" required="required">'.$catcourses.'</select>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">'.get_string("group", "form").'</span>
                          </div>
                          <select name="groupid" class="form-control" id="groupid" required="required">'.$groups.'</select>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">'.get_string("homework", "form").'</span>
                          </div>
                          <select name="homeworkid" class="form-control" id="homeworkid" required="required">'.$homeworks.'</select>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">'.get_string("attempt", "form").'</span>
                          </div>
                          <select name="attempt" class="form-control" id="attempt" required="required">
                            <option value="1" '.(($formdata->attempt==1)?'selected':'').' >'.get_string("firstattempt", "form").'</option>
                            <option value="2" '.(($formdata->attempt==2)?'selected':'').' >'.get_string("bestattempt", "form").'</option>
                          </select>
                        </div>
                      </div>
                      <input type="hidden" name="filtertype" value="'.$formdata->filtertype.'"/>
                      <input type="hidden" name="fromdate" value="'.$formdata->fromdate.'"/>
                      <input type="hidden" name="todate" value="'.$formdata->todate.'"/>
                      <div class="input-group mb-4">
                          <button type="submit" class="form-control btn btn-blue">'.get_string("search", "form").'</button>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
              <div class="col-md-6 grid-margin text-center transparent homeworkdata">
                <div class="row">
                  <div class="col-md-6 mb-4 mt-4 stretch-card1 transparent">
                    <div>'.get_string("strnotcompleted", "dashboard").'</div>
                    <a href="'.$report_incompleted.'">
                      <div class="card incomplete">
                        <div class="card-body">
                          <p class="fs-40 mb-2 count">'.$dashdata->homeworkkpi->notcompleted->count.'</p>
                          <p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->notcompleted->percent.'%</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-md-6 mb-4 mt-4 stretch-card1 transparent">
                    <div>'.get_string("strnotstarted", "dashboard").'</div>
                    <a href="'.$report_unstarted.'">
                      <div class="card notstarted">
                        <div class="card-body">
                          <p class="fs-40 mb-2 count">'.$dashdata->homeworkkpi->notstarted->count.'</p>
                          <p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->notstarted->percent.'%</p>
                        </div>
                      </a>
                    </div>
                  </div>
                  <div class="col-md-6 mb-4 stretch-card1 transparent">
                    <div>'.get_string("strcompleted", "dashboard").'</div>
                    <a href="'.$report_completed.'">
                      <div class="card completed">
                        <div class="card-body">
                          <p class="fs-40 mb-2 count">'.$dashdata->homeworkkpi->completed->count.'</p>
                          <p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->completed->percent.'%</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-md-6 mb-4 stretch-card1 transparent">
                    <div>'.get_string("strlatecompleted", "dashboard").'</div>
                    <a href="'.$report_latecompleted.'">
                      <div class="card latecompleted">
                        <div class="card-body">
                          <p class="fs-40 mb-2 count">'.$dashdata->homeworkkpi->latecompleted->count.'</p>
                          <p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->latecompleted->percent.'%</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-md-6 mb-4 stretch-card1 transparent">
                    <div>'.get_string("strpassed", "dashboard").'</div>
                    <a href="'.$report_passed.'">
                      <div class="card passed">
                        <div class="card-body">
                          <p class="fs-40 mb-2 count">'.$dashdata->homeworkkpi->passed->count.'</p>
                          <p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->passed->percent.'%</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-md-6 col-md-6 mb-4 stretch-card1 transparent">
                    <div>'.get_string("strnotpassed", "dashboard").'</div>
                    <a href="'.$report_failed.'">
                      <div class="card notpassed">
                        <div class="card-body">
                          <p class="fs-40 mb-2 count">'.$dashdata->homeworkkpi->notpassed->count.'</p>
                          <p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->notpassed->percent.'%</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div class="col-md-3 mb-4 stretch-card1 transparent"></div>
                  <div class="col-md-6 col-md-6 mb-4 stretch-card1 transparent">
                    <div>'.get_string("totaluserhomeworkcompleted", "form").'</div>
                      <div class="card lightblue">
                        <div class="card-body">
                          <br><p class="fs-40 mb-2 percent">'.$dashdata->homeworkkpi->totalquizcompleted.'</p><br>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-3 mb-4 stretch-card1 transparent"></div>
                  
                  
                </div>
              </div>
            </div>
      ';
      $kpihtml .='<script>
  $(document).ready(function(){
    var selectedgrade = null;    
    var allgrades = '.json_encode($allgrades).';
    var allgroups = '.json_encode($allgroup).';
    $("#categoryid").change(function(){
      var newoptions  ="<option value=\"0\">'.get_string("all", "site").'</option>";
      var gradeid = $(this).val();
      var selectedgrade = allgrades.find(x => x.categoryid === gradeid);
      console.log("selectedgrade-", selectedgrade);
      if(selectedgrade && Array.isArray(selectedgrade.allgroup)){
        allgroups = selectedgrade.allgroup;
        $.each( selectedgrade.allgroup, function( key, group ) {
          console.log("group- ", group);
          newoptions += \'<option value="\'+group.groupid+\'">\'+group.name+\'</option>\'
        });
      }
      console.log(newoptions);
      $("#groupid").html(newoptions);
    });
    $("#groupid").change(function(){
      var newoptions  ="<option value=\"0\">'.get_string("all", "site").'</option>";
      var groupid = $(this).val();
      var selectedgroup = allgroups.find(x => x.groupid === groupid);
      console.log("selectedgroup-", selectedgroup);
      if(selectedgroup && Array.isArray(selectedgroup.homeworks)){
        $.each( selectedgroup.homeworks, function( key, homework ) {
          console.log("group- ", homework);
          newoptions += \'<option value="\'+homework.id+\'">\'+homework.name+\'</option>\'
        });
      }
      $("#homeworkid").html(newoptions);
    });
    $(".filtertype").click(function(){
      $(".filtertype").removeClass("active");
      $(this).addClass("active");
      var filtertype = $(this).data("filtertype");
      console.log("filtertype- ", filtertype);
      $("input[name=\'filtertype\']").val(filtertype);
      if(filtertype != 4){
        $("#dashboardfilter").submit();
      }
    });
    $("#customdatefiler .datefilter").change(function(){
      var datetype = $(this).data("filterdate");
      var dateval = $(this).val();
      console.log("datetype- ", datetype);
      console.log("dateval- ", dateval);
      $("input[name=\'"+datetype+"\']").val(dateval);
      '. (!has_internet()?'$("#dashboardfilter").submit();':'') .'
    });
  })
  </script>';



  echo $OUTPUT->header();
  $html ='';
  $html .= '<div class="row">
            <div class="col-md-12 grid-margin">
              <div class="row">
                <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                  <h3 class="font-weight-bold">'.get_string("welcome", "site").' '.ucfirst($USER->firstname).'</h3>
                </div>';
  $html .=  '   <div class="col-12 col-xl-4">
                  <div class="justify-content-end d-flex">
                    <div class="btn-group btn-group-responsive" role="group" aria-label="Basic example">
                      <button type="button" data-filtertype="1" class="btn btn-outline-secondary filtertype  '.($formdata->filtertype == 1?'active':'').'">'.get_string("today", "form").'</button>
                      <button type="button" data-filtertype="2" class="btn btn-outline-secondary filtertype '.($formdata->filtertype == 2?'active':'').'">'.get_string("yesterday", "form").'</button>
                      <button type="button" data-filtertype="3" class="btn btn-outline-secondary filtertype '.($formdata->filtertype == 3?'active':'').'">'.get_string("thismonth", "form").'</button>
                      <button type="button" data-toggle="collapse" data-target="#customdatefiler" aria-expanded="'.($formdata->filtertype != 4?'false':'true').'" data-filtertype="4" class="btn btn-outline-secondary filtertype '.($formdata->filtertype == 4?'active':'').'">'.get_string("tochoose", "form").'</button>
                    </div>                 
                  </div>
                  <div id="customdatefiler" class="'.($formdata->filtertype != 4?'collapse':'').' mt-4" aria-expanded="'.($formdata->filtertype != 4?'false':'true').'" '.($formdata->filtertype != 4?'style="height: 0px";':'').'>
                    <div class="form-group">
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text">'.get_string("from", "form").'</span>
                        </div>
                        <input type="date" class="form-control datefilter" value="'.$formdata->fromdate.'" data-filterdate="fromdate" max="'.date('Y-m-d').'"/>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text">'.get_string("to", "form").'</span>
                        </div>
                        <input type="date" class="form-control datefilter" value="'.  $formdata->todate.'" data-filterdate="todate" min="'.$formdata->fromdate.'" max="'.date('Y-m-d').'"/>
                      </div>
                    </div>
                  </div>
                </div>
';                
  $html .= '  </div>
            </div>
          </div>';
  $html .= $kpihtml;
  $html .='
          <div class="row">
            <div class="col-12 grid-margin transparent">
              <div class="row">
                <div class="col-md-4 mb-4 stretch-card transparent">
                  <div class="card card-tale">
                    <div class="card-body">
                      <p class="mb-4">Total User</p>
                      <p class="fs-30 mb-2">'.sizeof($dashboarddata->usersdata->credentials).'</p>
                      <p>'.get_string("lastsynced",'site').': '.timestamp_to_date($dashboarddata->usersdata->lastsynced).'</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 mb-4 stretch-card transparent">
                  <div class="card card-dark-blue">
                    <div class="card-body">
                      <p class="mb-4">Total Homeworks</p>
                      <p class="fs-30 mb-2">'.sizeof($dashboarddata->homeworkdata->homeworks).'</p>
                      <p>'.get_string("lastsynced",'site').': '.timestamp_to_date($dashboarddata->homeworkdata->lastsynced).'</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 mb-4 stretch-card transparent">
                  <div class="card card-light-blue">
                    <div class="card-body">
                      <p class="mb-4">Awaiting userdata Synced</p>
                      <div class="d-flex justify-content-between align-items-center w-100">
                        <div>
                          <p class="fs-30 mb-2">'.$dashboarddata->awaitingsyncdata->awaitingcount.'</p>
                          <p>'.get_string("lastsynced",'site').': '.timestamp_to_date($dashboarddata->awaitingsyncdata->lastsynced).'</p>
                        </div>
                        '.((has_internet() && $dashboarddata->awaitingsyncdata->awaitingcount>0)?'<a class="btn btn-primary btn-sm" href="'.$CFG->wwwroot.'/dashboard?syncnow=all">'.get_string("syncnow",'site').'</a>':'').'
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
  ';
?>  
<?php
  echo $html;
  echo $OUTPUT->footer();