<?php
  require_once("../config.php");
  $syncnow = optional_param("syncnow", "");
  if($syncnow){
    syncAlluserdata($syncnow);
    redirect("{$CFG->wwwroot}/reports");
  }
  require_login();
  $OUTPUT->loadjquery();
  echo $OUTPUT->header();
  $alllocaldatafiles = get_alllocaldata();

$html = '';
//$html .= '<pre>'.print_r($alllocaldatafiles, true).'</pre>';
$html .= '<div class="row">
            <div class="col-12 stretch-card grid-margin">
              <div class="card">
                <div class="card-body">
                  <a class="btn btn-primary mb-10" href="'.$CFG->wwwroot.'/reports/classprofile/">'.get_string("classprofile", "site").'</a>
                  <a class="btn btn-primary mb-10" href="'.$CFG->wwwroot.'/reports/userdata/">'.get_string("userdata", "site").'</a>
                </div>
              </div>
            </div>
          </div>';
  $html .='<script>
              $("#userlist").DataTable();
            </script>';
  echo $html;
  echo $OUTPUT->footer();