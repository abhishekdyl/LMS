<?php

class DependencyTest extends \PHPUnit\Framework\TestCase
{
    public function testTrueIsTrue()
    {
        $this->assertTrue(true);
    }
}
