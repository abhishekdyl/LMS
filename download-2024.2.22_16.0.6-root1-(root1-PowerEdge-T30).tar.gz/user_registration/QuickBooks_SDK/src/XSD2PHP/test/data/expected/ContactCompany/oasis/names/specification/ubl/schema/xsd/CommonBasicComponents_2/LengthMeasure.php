<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LengthMeasureType
 * @xmlName LengthMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LengthMeasure
 */
class LengthMeasure extends LengthMeasureType
{
} // end class LengthMeasure
