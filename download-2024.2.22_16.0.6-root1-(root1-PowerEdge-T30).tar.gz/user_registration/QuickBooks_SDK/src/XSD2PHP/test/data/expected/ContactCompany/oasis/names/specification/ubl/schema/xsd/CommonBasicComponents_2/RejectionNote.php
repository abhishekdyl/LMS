<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType RejectionNoteType
 * @xmlName RejectionNote
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\RejectionNote
 */
class RejectionNote extends RejectionNoteType
{
} // end class RejectionNote
