<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CopyIndicatorType
 * @xmlName CopyIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CopyIndicator
 */
class CopyIndicator extends CopyIndicatorType
{
} // end class CopyIndicator
