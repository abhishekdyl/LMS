<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType SpecialInstructionsType
 * @xmlName SpecialInstructions
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\SpecialInstructions
 */
class SpecialInstructions extends SpecialInstructionsType
{
} // end class SpecialInstructions
