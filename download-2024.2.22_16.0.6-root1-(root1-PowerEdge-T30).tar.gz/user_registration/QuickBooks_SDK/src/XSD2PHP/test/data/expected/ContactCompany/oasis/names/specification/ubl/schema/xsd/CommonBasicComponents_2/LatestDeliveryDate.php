<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LatestDeliveryDateType
 * @xmlName LatestDeliveryDate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LatestDeliveryDate
 */
class LatestDeliveryDate extends LatestDeliveryDateType
{
} // end class LatestDeliveryDate
