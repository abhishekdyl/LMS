<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ChargeTotalAmountType
 * @xmlName ChargeTotalAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ChargeTotalAmount
 */
class ChargeTotalAmount extends ChargeTotalAmountType
{
} // end class ChargeTotalAmount
