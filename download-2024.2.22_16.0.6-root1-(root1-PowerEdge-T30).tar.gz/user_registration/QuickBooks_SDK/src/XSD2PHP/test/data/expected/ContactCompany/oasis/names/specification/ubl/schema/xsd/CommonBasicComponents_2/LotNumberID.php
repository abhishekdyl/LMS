<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LotNumberIDType
 * @xmlName LotNumberID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LotNumberID
 */
class LotNumberID extends LotNumberIDType
{
} // end class LotNumberID
