<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType UnitQuantityType
 * @xmlName UnitQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\UnitQuantity
 */
class UnitQuantity extends UnitQuantityType
{
} // end class UnitQuantity
