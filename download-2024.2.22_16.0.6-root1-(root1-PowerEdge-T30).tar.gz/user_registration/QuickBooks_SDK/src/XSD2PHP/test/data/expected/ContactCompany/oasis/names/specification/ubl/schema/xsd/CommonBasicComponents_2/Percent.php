<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PercentType
 * @xmlName Percent
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Percent
 */
class Percent extends PercentType
{
} // end class Percent
