<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ReturnabilityIndicatorType
 * @xmlName ReturnabilityIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ReturnabilityIndicator
 */
class ReturnabilityIndicator extends ReturnabilityIndicatorType
{
} // end class ReturnabilityIndicator
