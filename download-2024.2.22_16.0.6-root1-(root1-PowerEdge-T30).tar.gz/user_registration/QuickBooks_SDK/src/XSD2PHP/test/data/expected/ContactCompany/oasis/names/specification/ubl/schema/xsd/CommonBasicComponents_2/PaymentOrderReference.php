<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PaymentOrderReferenceType
 * @xmlName PaymentOrderReference
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PaymentOrderReference
 */
class PaymentOrderReference extends PaymentOrderReferenceType
{
} // end class PaymentOrderReference
