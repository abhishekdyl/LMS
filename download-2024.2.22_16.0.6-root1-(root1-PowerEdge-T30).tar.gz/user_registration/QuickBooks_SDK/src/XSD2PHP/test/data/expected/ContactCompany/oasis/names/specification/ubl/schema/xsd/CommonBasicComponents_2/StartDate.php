<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType StartDateType
 * @xmlName StartDate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\StartDate
 */
class StartDate extends StartDateType
{
} // end class StartDate
