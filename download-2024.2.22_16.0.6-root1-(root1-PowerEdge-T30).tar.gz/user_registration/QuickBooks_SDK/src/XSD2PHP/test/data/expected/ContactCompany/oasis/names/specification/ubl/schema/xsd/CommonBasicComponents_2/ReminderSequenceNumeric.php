<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ReminderSequenceNumericType
 * @xmlName ReminderSequenceNumeric
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ReminderSequenceNumeric
 */
class ReminderSequenceNumeric extends ReminderSequenceNumericType
{
} // end class ReminderSequenceNumeric
