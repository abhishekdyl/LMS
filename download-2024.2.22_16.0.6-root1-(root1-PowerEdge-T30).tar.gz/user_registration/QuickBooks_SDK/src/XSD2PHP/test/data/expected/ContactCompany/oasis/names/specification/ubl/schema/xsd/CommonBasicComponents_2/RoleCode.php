<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType RoleCodeType
 * @xmlName RoleCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\RoleCode
 */
class RoleCode extends RoleCodeType
{
} // end class RoleCode
