<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType SourceCurrencyBaseRateType
 * @xmlName SourceCurrencyBaseRate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\SourceCurrencyBaseRate
 */
class SourceCurrencyBaseRate extends SourceCurrencyBaseRateType
{
} // end class SourceCurrencyBaseRate
