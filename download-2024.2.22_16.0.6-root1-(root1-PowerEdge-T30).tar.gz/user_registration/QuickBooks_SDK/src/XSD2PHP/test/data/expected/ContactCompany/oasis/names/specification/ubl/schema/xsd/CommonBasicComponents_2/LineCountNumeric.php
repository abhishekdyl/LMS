<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LineCountNumericType
 * @xmlName LineCountNumeric
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LineCountNumeric
 */
class LineCountNumeric extends LineCountNumericType
{
} // end class LineCountNumeric
