<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MaximumQuantityType
 * @xmlName MaximumQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MaximumQuantity
 */
class MaximumQuantity extends MaximumQuantityType
{
} // end class MaximumQuantity
