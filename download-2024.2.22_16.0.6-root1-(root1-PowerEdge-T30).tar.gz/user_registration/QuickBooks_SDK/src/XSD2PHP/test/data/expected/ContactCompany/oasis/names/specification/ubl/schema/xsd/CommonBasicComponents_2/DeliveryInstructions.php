<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DeliveryInstructionsType
 * @xmlName DeliveryInstructions
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DeliveryInstructions
 */
class DeliveryInstructions extends DeliveryInstructionsType
{
} // end class DeliveryInstructions
