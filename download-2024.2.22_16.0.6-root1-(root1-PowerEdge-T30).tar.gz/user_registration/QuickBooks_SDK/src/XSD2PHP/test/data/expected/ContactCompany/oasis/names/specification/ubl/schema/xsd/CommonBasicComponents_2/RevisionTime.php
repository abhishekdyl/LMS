<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType RevisionTimeType
 * @xmlName RevisionTime
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\RevisionTime
 */
class RevisionTime extends RevisionTimeType
{
} // end class RevisionTime
