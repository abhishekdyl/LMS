<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AgencyIDType
 * @xmlName AgencyID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AgencyID
 */
class AgencyID extends AgencyIDType
{
} // end class AgencyID
