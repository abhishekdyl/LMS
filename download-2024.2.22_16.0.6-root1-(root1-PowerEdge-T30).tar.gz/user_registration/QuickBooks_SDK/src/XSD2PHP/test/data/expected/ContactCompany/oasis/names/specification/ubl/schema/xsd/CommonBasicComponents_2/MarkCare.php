<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MarkCareType
 * @xmlName MarkCare
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MarkCare
 */
class MarkCare extends MarkCareType
{
} // end class MarkCare
