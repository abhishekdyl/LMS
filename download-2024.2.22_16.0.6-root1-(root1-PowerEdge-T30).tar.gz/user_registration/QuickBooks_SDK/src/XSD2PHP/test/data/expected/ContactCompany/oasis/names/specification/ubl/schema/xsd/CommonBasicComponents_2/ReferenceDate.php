<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ReferenceDateType
 * @xmlName ReferenceDate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ReferenceDate
 */
class ReferenceDate extends ReferenceDateType
{
} // end class ReferenceDate
