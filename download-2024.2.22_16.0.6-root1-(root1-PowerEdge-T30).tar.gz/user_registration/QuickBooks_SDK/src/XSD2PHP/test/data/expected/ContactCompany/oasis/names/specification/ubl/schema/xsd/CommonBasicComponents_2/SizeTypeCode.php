<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType SizeTypeCodeType
 * @xmlName SizeTypeCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\SizeTypeCode
 */
class SizeTypeCode extends SizeTypeCodeType
{
} // end class SizeTypeCode
