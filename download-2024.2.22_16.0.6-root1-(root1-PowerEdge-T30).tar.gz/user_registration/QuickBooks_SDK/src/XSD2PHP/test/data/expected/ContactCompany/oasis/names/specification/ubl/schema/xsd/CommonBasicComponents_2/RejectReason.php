<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType RejectReasonType
 * @xmlName RejectReason
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\RejectReason
 */
class RejectReason extends RejectReasonType
{
} // end class RejectReason
