<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType RoundingAmountType
 * @xmlName RoundingAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\RoundingAmount
 */
class RoundingAmount extends RoundingAmountType
{
} // end class RoundingAmount
