<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType TimingComplaintCodeType
 * @xmlName TimingComplaintCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\TimingComplaintCode
 */
class TimingComplaintCode extends TimingComplaintCodeType
{
} // end class TimingComplaintCode
