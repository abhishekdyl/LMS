<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DocumentIDType
 * @xmlName DocumentID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DocumentID
 */
class DocumentID extends DocumentIDType
{
} // end class DocumentID
