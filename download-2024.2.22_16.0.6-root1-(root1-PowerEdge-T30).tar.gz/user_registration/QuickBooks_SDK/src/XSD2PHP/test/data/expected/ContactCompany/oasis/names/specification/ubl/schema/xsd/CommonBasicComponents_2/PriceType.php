<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PriceTypeType
 * @xmlName PriceType
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PriceType
 */
class PriceType extends PriceTypeType
{
} // end class PriceType
