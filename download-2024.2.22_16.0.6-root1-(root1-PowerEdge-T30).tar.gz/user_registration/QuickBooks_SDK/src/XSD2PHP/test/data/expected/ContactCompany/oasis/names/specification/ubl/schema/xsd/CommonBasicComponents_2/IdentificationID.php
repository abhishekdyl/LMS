<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType IdentificationIDType
 * @xmlName IdentificationID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\IdentificationID
 */
class IdentificationID extends IdentificationIDType
{
} // end class IdentificationID
