<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType AttributeIDType
 * @xmlName AttributeID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\AttributeID
 */
class AttributeID extends AttributeIDType
{
} // end class AttributeID
