<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ResponseCodeType
 * @xmlName ResponseCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ResponseCode
 */
class ResponseCode extends ResponseCodeType
{
} // end class ResponseCode
