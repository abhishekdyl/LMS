<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LineType
 * @xmlName Line
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Line
 */
class Line extends LineType
{
} // end class Line
