<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DocumentHashType
 * @xmlName DocumentHash
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DocumentHash
 */
class DocumentHash extends DocumentHashType
{
} // end class DocumentHash
