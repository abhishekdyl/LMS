<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PackingMaterialType
 * @xmlName PackingMaterial
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PackingMaterial
 */
class PackingMaterial extends PackingMaterialType
{
} // end class PackingMaterial
