<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType StreetNameType
 * @xmlName StreetName
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\StreetName
 */
class StreetName extends StreetNameType
{
} // end class StreetName
