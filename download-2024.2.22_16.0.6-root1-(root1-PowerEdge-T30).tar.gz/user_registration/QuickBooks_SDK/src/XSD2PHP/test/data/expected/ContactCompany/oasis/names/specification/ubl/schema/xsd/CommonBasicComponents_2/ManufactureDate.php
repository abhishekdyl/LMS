<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ManufactureDateType
 * @xmlName ManufactureDate
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ManufactureDate
 */
class ManufactureDate extends ManufactureDateType
{
} // end class ManufactureDate
