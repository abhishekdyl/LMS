<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PaymentNoteType
 * @xmlName PaymentNote
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PaymentNote
 */
class PaymentNote extends PaymentNoteType
{
} // end class PaymentNote
