<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType TotalInvoiceAmountType
 * @xmlName TotalInvoiceAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\TotalInvoiceAmount
 */
class TotalInvoiceAmount extends TotalInvoiceAmountType
{
} // end class TotalInvoiceAmount
