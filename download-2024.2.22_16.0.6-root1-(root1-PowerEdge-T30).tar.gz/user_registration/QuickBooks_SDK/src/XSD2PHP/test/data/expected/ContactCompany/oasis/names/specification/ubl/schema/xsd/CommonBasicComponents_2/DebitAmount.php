<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DebitAmountType
 * @xmlName DebitAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DebitAmount
 */
class DebitAmount extends DebitAmountType
{
} // end class DebitAmount
