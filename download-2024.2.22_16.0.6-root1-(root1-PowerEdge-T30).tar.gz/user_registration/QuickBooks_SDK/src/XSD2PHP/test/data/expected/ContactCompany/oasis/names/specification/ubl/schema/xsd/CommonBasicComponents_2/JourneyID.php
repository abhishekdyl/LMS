<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType JourneyIDType
 * @xmlName JourneyID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\JourneyID
 */
class JourneyID extends JourneyIDType
{
} // end class JourneyID
