<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MinimumQuantityType
 * @xmlName MinimumQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MinimumQuantity
 */
class MinimumQuantity extends MinimumQuantityType
{
} // end class MinimumQuantity
