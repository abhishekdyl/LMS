<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType MinimumBackorderQuantityType
 * @xmlName MinimumBackorderQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\MinimumBackorderQuantity
 */
class MinimumBackorderQuantity extends MinimumBackorderQuantityType
{
} // end class MinimumBackorderQuantity
