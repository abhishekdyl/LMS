<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DateType
 * @xmlName Date
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Date
 */
class Date extends DateType
{
} // end class Date
