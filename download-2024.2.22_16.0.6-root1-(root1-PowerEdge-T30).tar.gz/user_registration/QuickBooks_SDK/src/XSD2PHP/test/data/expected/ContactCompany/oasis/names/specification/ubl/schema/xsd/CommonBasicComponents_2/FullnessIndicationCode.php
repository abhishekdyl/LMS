<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType FullnessIndicationCodeType
 * @xmlName FullnessIndicationCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\FullnessIndicationCode
 */
class FullnessIndicationCode extends FullnessIndicationCodeType
{
} // end class FullnessIndicationCode
