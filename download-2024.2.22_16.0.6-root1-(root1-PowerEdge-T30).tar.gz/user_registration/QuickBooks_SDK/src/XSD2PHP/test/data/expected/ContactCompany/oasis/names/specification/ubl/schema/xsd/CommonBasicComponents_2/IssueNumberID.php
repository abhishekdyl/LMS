<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType IssueNumberIDType
 * @xmlName IssueNumberID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\IssueNumberID
 */
class IssueNumberID extends IssueNumberIDType
{
} // end class IssueNumberID
