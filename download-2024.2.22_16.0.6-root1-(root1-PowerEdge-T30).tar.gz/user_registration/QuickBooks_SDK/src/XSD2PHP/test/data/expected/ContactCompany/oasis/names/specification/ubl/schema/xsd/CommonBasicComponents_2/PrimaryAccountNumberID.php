<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PrimaryAccountNumberIDType
 * @xmlName PrimaryAccountNumberID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PrimaryAccountNumberID
 */
class PrimaryAccountNumberID extends PrimaryAccountNumberIDType
{
} // end class PrimaryAccountNumberID
