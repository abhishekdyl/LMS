<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LossRiskType
 * @xmlName LossRisk
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LossRisk
 */
class LossRisk extends LossRiskType
{
} // end class LossRisk
