<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType ReferenceEventCodeType
 * @xmlName ReferenceEventCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\ReferenceEventCode
 */
class ReferenceEventCode extends ReferenceEventCodeType
{
} // end class ReferenceEventCode
