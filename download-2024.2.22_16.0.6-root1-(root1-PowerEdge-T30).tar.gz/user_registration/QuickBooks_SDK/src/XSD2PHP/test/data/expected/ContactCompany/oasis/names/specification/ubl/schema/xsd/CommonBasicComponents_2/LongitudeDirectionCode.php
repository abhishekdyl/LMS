<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LongitudeDirectionCodeType
 * @xmlName LongitudeDirectionCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LongitudeDirectionCode
 */
class LongitudeDirectionCode extends LongitudeDirectionCodeType
{
} // end class LongitudeDirectionCode
