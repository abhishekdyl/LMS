<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LongitudeMinutesMeasureType
 * @xmlName LongitudeMinutesMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LongitudeMinutesMeasure
 */
class LongitudeMinutesMeasure extends LongitudeMinutesMeasureType
{
} // end class LongitudeMinutesMeasure
