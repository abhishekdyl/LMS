<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType UBLVersionIDType
 * @xmlName UBLVersionID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\UBLVersionID
 */
class UBLVersionID extends UBLVersionIDType
{
} // end class UBLVersionID
