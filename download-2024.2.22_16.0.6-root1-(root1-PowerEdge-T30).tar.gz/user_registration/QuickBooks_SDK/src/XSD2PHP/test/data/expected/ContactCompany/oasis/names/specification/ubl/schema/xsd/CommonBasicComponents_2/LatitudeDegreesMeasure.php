<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType LatitudeDegreesMeasureType
 * @xmlName LatitudeDegreesMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\LatitudeDegreesMeasure
 */
class LatitudeDegreesMeasure extends LatitudeDegreesMeasureType
{
} // end class LatitudeDegreesMeasure
