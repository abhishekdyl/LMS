<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType CreditedQuantityType
 * @xmlName CreditedQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\CreditedQuantity
 */
class CreditedQuantity extends CreditedQuantityType
{
} // end class CreditedQuantity
