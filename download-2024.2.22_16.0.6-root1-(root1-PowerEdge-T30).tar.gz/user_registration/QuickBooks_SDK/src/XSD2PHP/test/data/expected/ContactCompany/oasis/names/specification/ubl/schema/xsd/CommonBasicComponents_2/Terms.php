<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType TermsType
 * @xmlName Terms
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\Terms
 */
class Terms extends TermsType
{
} // end class Terms
