<?php
namespace dk\nordsign\schema\ContactPerson;

/**
 * @xmlNamespace urn:dk:nordsign:schema:ContactPerson
 * @xmlType ContactPersonType
 * @xmlName ContactPerson
 * @var dk\nordsign\schema\ContactPerson\ContactPerson
 */
class ContactPerson extends ContactPersonType
{
} // end class ContactPerson
