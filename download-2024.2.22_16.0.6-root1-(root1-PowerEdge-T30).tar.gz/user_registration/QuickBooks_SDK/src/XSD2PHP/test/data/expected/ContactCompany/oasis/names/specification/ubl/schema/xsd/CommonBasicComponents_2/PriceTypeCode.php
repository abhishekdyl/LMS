<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PriceTypeCodeType
 * @xmlName PriceTypeCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PriceTypeCode
 */
class PriceTypeCode extends PriceTypeCodeType
{
} // end class PriceTypeCode
