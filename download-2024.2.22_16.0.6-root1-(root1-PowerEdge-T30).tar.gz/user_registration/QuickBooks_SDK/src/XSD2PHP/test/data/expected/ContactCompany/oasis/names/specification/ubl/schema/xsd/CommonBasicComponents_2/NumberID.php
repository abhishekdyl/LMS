<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NumberIDType
 * @xmlName NumberID
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NumberID
 */
class NumberID extends NumberIDType
{
} // end class NumberID
