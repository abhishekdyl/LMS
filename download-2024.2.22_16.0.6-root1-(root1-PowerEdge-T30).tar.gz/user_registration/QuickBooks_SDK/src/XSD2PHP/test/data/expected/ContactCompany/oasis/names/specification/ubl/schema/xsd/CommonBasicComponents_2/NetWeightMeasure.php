<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NetWeightMeasureType
 * @xmlName NetWeightMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NetWeightMeasure
 */
class NetWeightMeasure extends NetWeightMeasureType
{
} // end class NetWeightMeasure
