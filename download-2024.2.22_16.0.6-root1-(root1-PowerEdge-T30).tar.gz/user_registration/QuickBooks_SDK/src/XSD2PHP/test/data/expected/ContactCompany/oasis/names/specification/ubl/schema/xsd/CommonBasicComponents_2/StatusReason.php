<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType StatusReasonType
 * @xmlName StatusReason
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\StatusReason
 */
class StatusReason extends StatusReasonType
{
} // end class StatusReason
