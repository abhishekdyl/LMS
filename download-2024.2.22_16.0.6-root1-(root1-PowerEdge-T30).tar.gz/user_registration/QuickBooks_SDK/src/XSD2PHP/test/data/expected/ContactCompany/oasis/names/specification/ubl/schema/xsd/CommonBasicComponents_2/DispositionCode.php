<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType DispositionCodeType
 * @xmlName DispositionCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\DispositionCode
 */
class DispositionCode extends DispositionCodeType
{
} // end class DispositionCode
