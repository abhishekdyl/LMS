<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType RegistrationNationalityType
 * @xmlName RegistrationNationality
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\RegistrationNationality
 */
class RegistrationNationality extends RegistrationNationalityType
{
} // end class RegistrationNationality
