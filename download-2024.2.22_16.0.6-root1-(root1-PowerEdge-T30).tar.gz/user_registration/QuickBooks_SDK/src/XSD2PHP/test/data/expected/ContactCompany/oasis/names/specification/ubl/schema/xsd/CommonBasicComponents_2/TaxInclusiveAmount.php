<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType TaxInclusiveAmountType
 * @xmlName TaxInclusiveAmount
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\TaxInclusiveAmount
 */
class TaxInclusiveAmount extends TaxInclusiveAmountType
{
} // end class TaxInclusiveAmount
