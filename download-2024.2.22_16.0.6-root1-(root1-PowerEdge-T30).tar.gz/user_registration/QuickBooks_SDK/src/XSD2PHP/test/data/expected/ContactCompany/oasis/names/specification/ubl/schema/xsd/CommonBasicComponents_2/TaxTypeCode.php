<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType TaxTypeCodeType
 * @xmlName TaxTypeCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\TaxTypeCode
 */
class TaxTypeCode extends TaxTypeCodeType
{
} // end class TaxTypeCode
