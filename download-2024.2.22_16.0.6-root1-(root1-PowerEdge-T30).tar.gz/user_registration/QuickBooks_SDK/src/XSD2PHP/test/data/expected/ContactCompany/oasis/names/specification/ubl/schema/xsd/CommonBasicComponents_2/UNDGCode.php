<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType UNDGCodeType
 * @xmlName UNDGCode
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\UNDGCode
 */
class UNDGCode extends UNDGCodeType
{
} // end class UNDGCode
