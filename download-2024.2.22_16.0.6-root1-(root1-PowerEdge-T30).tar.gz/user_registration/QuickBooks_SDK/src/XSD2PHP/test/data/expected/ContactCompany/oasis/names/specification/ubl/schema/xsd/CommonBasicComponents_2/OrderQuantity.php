<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType OrderQuantityType
 * @xmlName OrderQuantity
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\OrderQuantity
 */
class OrderQuantity extends OrderQuantityType
{
} // end class OrderQuantity
