<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType NetNetWeightMeasureType
 * @xmlName NetNetWeightMeasure
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\NetNetWeightMeasure
 */
class NetNetWeightMeasure extends NetNetWeightMeasureType
{
} // end class NetNetWeightMeasure
