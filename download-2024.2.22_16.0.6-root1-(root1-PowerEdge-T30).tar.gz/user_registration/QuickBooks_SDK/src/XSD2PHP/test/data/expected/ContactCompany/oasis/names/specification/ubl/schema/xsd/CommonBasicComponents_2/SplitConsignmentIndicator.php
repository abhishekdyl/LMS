<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType SplitConsignmentIndicatorType
 * @xmlName SplitConsignmentIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\SplitConsignmentIndicator
 */
class SplitConsignmentIndicator extends SplitConsignmentIndicatorType
{
} // end class SplitConsignmentIndicator
