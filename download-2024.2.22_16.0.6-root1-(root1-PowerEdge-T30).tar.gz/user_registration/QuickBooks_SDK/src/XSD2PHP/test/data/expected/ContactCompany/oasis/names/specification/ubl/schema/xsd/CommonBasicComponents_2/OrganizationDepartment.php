<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType OrganizationDepartmentType
 * @xmlName OrganizationDepartment
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\OrganizationDepartment
 */
class OrganizationDepartment extends OrganizationDepartmentType
{
} // end class OrganizationDepartment
