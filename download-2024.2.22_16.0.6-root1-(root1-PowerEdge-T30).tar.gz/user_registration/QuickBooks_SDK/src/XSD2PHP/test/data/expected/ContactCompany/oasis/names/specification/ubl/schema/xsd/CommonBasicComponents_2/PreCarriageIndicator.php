<?php
namespace oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2;

/**
 * @xmlNamespace urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2
 * @xmlType PreCarriageIndicatorType
 * @xmlName PreCarriageIndicator
 * @var oasis\names\specification\ubl\schema\xsd\CommonBasicComponents_2\PreCarriageIndicator
 */
class PreCarriageIndicator extends PreCarriageIndicatorType
{
} // end class PreCarriageIndicator
