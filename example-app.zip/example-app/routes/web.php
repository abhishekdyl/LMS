<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\fileupload;
use App\Http\Controllers\createusercontroller;
use App\Http\Controllers\modelbindingController;
use App\Http\Controllers\relationContoller;
use Illuminate\Support\Str;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/user', function () {
    return view('user');
});
Route::post('uploadfile',[fileupload::class,'uploadimg']);
// Route::view('createuser','createuser'); //--------CRUD------------
Route::get('createuser',[createusercontroller::class,'userlist']);
Route::post('createusercontroller',[createusercontroller::class,'createuser']);
Route::get('delete/{id}',[createusercontroller::class,'delete']);
Route::get('update/{id}',[createusercontroller::class,'update']);
Route::post('edit',[createusercontroller::class,'edit']);

Route::get('join',[modelbindingController::class,'tablejoin']);
//------------modelbinding-----------------
Route::get('device/{keyname:name}',[modelbindingController::class,'mbinding']);
//------------relation-----------------
Route::get('relation',[relationContoller::class,'otmanyrelation']);

//fluent strings
$string = 'hi, welcome to the laravel';
// $string = Str:: ucfirst($string);
// $string = Str:: replaceFirst('Hi','Hello',$string);
// $string = Str:: camel($string);
//-----------------OR USE LIKE FLUENT STRING (METHOD CHAINING) ---------------------
$string = Str:: of($string)->ucfirst($string)
->replaceFirst('Hi','Hello',$string) 
->camel($string);
echo $string;
