<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <body>
        <h3>File upload data</h3>
        
    <form action="uploadfile" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="doc"><br/>
        <input type="submit">
    </form>


    </body>
</html> <?php /**PATH /var/www/html/laravel/example-app/resources/views/user.blade.php ENDPATH**/ ?>