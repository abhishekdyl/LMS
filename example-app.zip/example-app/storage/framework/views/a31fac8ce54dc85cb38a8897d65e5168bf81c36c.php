<h1>Update User</h1>
<form action="/edit" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($upuser->id); ?>">
    <label for="name">Name : </label>
    <input type="text" name="name" id="name" value="<?php echo e($upuser->name); ?>"><br/><br/>
    <label for="email">Email : </label>
    <input type="text" name="email" id="email" value="<?php echo e($upuser->email); ?>"><br/><br/>
    <label for="address">Address : </label>
    <input type="text" name="address" id="address" value="<?php echo e($upuser->address); ?>"><br/><br/>
    <label for="number">Contect : </label>
    <input type="text" name="number" id="number" value="<?php echo e($upuser->contact); ?>"><br/><br/><br/>

    <input type="submit" value="update">
</form>
<?php /**PATH /var/www/html/laravel/example-app/resources/views/edit.blade.php ENDPATH**/ ?>