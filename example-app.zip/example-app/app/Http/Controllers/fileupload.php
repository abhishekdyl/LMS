<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class fileupload extends Controller
{
    function uploadimg(Request $req){
        return $req->file('doc')->store('img');
        // return $req->file('doc')->storeAs('img',getClientOriginalName());
    }
}
