<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\createuser;

class createusercontroller extends Controller
{
    function createuser(Request $req){
        $createuser = new createuser();
        $createuser->name = $req->name;
        $createuser->email = $req->email;
        $createuser->address = $req->address;
        $createuser->contact = $req->number;
        $createuser->save();
        return redirect('createuser');
        // return self::userlist();
        
    }

    function userlist(){
        $users = createuser::all();
        return view('createuser',['datausers'=>$users]);
    }    
    
    function delete($id){
        $data = createuser::find($id);
        $data->delete();
        return redirect('createuser');
    }

    function update($id){
        $data = createuser::find($id);
        return view('edit',['upuser'=>$data]);
    }
    
    function edit(Request $req){
        $data = createuser::find($req->id);
        $data->name = $req->name;
        $data->email = $req->email;
        $data->address = $req->address;
        $data->contact = $req->number;
        $data->save();
        return redirect('createuser');

    }
}
