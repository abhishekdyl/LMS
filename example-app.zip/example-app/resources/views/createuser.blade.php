<h1>Create Users</h1>
<form action="createusercontroller" method="post">
    @csrf
    <label for="name">Name : </label>
    <input type="text" name="name" id="name" placeholder="enter your name"><br/><br/>
    <label for="email">Email : </label>
    <input type="text" name="email" id="email" placeholder="enter your email"><br/><br/>
    <label for="address">Address : </label>
    <input type="text" name="address" id="address" placeholder="enter your address"><br/><br/>
    <label for="number">Contect : </label>
    <input type="text" name="number" id="number" placeholder="enter your contect"><br/><br/><br/>

    <input type="submit" value="Submit">
</form>


<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>Contact</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($datausers as $key => $user)
        <tr>
            <td>{{$user->id}}</td>
            <td>{{$user->name}}</td>
            <td>{{$user->email}}</td>
            <td>{{$user->address}}</td>
            <td>{{$user->contact}}</td>
            <td><a href="/update/{{$user->id}}">edit</a>&nbsp;<a href="/delete/{{$user->id}}">del</a></td>
        </tr>
        @endforeach
    </tbody>
</table>