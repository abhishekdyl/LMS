<h1>Update User</h1>
<form action="/edit" method="post">
    @csrf
    <input type="hidden" name="id" value="{{$upuser->id}}">
    <label for="name">Name : </label>
    <input type="text" name="name" id="name" value="{{$upuser->name}}"><br/><br/>
    <label for="email">Email : </label>
    <input type="text" name="email" id="email" value="{{$upuser->email}}"><br/><br/>
    <label for="address">Address : </label>
    <input type="text" name="address" id="address" value="{{$upuser->address}}"><br/><br/>
    <label for="number">Contect : </label>
    <input type="text" name="number" id="number" value="{{$upuser->contact}}"><br/><br/><br/>

    <input type="submit" value="update">
</form>
