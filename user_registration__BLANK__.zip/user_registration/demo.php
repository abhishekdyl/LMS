<?php
require_once('../../config.php');
global $DB, $CFG, $PAGE, $USER;

echo 'hello';


?>