<?php
return array(
    'authorizationRequestUrl' => 'https://appcenter.intuit.com/connect/oauth2',
    'tokenEndPointUrl' => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
    'client_id' => 'ABXH0SX1h2Kj8cdUuq8oAbhPBHzPenHKl0FOiUe30M9owPKkv8',
    'client_secret' => 'C0HZUJXzBVgYlgjhOJPwdDAXPf8kMbWIRPNVS50P',
    'oauth_scope' => 'com.intuit.quickbooks.accounting com.intuit.quickbooks.payment openid profile email phone address',
    // 'oauth_redirect_uri' => '',
    'oauth_redirect_uri' => 'https://7974-2405-204-1380-44e7-295f-497-d0fc-b5a5.ngrok-free.app/qbk/callback.php',
    'QBORealmID' => '9130357982315866',
)
?>
